<?php
include 'style.php';
  $show = htmlspecialchars($_GET["showname"]);	
  $day= $_GET["page"];
  $user=$_GET["user"];
  $phantom=$_GET['phantom'];
  $mode=$_GET['mode'];

$dbname = "stagepatchpreferences";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, "SELECT * FROM showlist WHERE showname = '$show'");
$row = mysqli_fetch_array($query);
$lineup= $row['numbands'];
if (isset($_GET['page'])){$day= $_GET["page"];}
else{$day=$row['defaultday'];
echo "default day is {$day} and {$defaultday}";}

if ($day == "1"){
	$bands = ["filler", htmlspecialchars_decode($row['band101'], ENT_QUOTES), htmlspecialchars_decode($row['band102'], ENT_QUOTES), htmlspecialchars_decode($row['band103'], ENT_QUOTES), htmlspecialchars_decode($row['band104'], ENT_QUOTES), htmlspecialchars_decode($row['band105'], ENT_QUOTES), htmlspecialchars_decode($row['band106'], ENT_QUOTES),htmlspecialchars_decode($row['band107'], ENT_QUOTES), htmlspecialchars_decode($row['band108'], ENT_QUOTES),htmlspecialchars_decode($row['band109'], ENT_QUOTES), htmlspecialchars_decode($row['band110'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band111'], ENT_QUOTES), htmlspecialchars_decode($row['band112'], ENT_QUOTES), htmlspecialchars_decode($row['band113'], ENT_QUOTES), htmlspecialchars_decode($row['band114'], ENT_QUOTES), htmlspecialchars_decode($row['band115'], ENT_QUOTES), htmlspecialchars_decode($row['band116'], ENT_QUOTES),htmlspecialchars_decode($row['band117'], ENT_QUOTES), htmlspecialchars_decode($row['band118'], ENT_QUOTES),htmlspecialchars_decode($row['band119'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
}elseif ($day == "2"){
	$bands = ["filler", htmlspecialchars_decode($row['band201'], ENT_QUOTES), htmlspecialchars_decode($row['band202'], ENT_QUOTES), htmlspecialchars_decode($row['band203'], ENT_QUOTES), htmlspecialchars_decode($row['band204'], ENT_QUOTES), htmlspecialchars_decode($row['band205'], ENT_QUOTES), htmlspecialchars_decode($row['band206'], ENT_QUOTES),htmlspecialchars_decode($row['band207'], ENT_QUOTES), htmlspecialchars_decode($row['band208'], ENT_QUOTES),htmlspecialchars_decode($row['band209'], ENT_QUOTES), htmlspecialchars_decode($row['band220'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band211'], ENT_QUOTES), htmlspecialchars_decode($row['band212'], ENT_QUOTES), htmlspecialchars_decode($row['band213'], ENT_QUOTES), htmlspecialchars_decode($row['band214'], ENT_QUOTES), htmlspecialchars_decode($row['band215'], ENT_QUOTES), htmlspecialchars_decode($row['band216'], ENT_QUOTES),htmlspecialchars_decode($row['band217'], ENT_QUOTES), htmlspecialchars_decode($row['band218'], ENT_QUOTES),htmlspecialchars_decode($row['band219'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
}elseif ($day == "3"){
	$bands = ["filler", htmlspecialchars_decode($row['band301'], ENT_QUOTES), htmlspecialchars_decode($row['band302'], ENT_QUOTES), htmlspecialchars_decode($row['band303'], ENT_QUOTES), htmlspecialchars_decode($row['band304'], ENT_QUOTES), htmlspecialchars_decode($row['band305'], ENT_QUOTES), htmlspecialchars_decode($row['band306'], ENT_QUOTES),htmlspecialchars_decode($row['band307'], ENT_QUOTES), htmlspecialchars_decode($row['band308'], ENT_QUOTES),htmlspecialchars_decode($row['band309'], ENT_QUOTES), htmlspecialchars_decode($row['band310'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band311'], ENT_QUOTES), htmlspecialchars_decode($row['band312'], ENT_QUOTES), htmlspecialchars_decode($row['band313'], ENT_QUOTES), htmlspecialchars_decode($row['band314'], ENT_QUOTES), htmlspecialchars_decode($row['band315'], ENT_QUOTES), htmlspecialchars_decode($row['band316'], ENT_QUOTES),htmlspecialchars_decode($row['band317'], ENT_QUOTES), htmlspecialchars_decode($row['band318'], ENT_QUOTES),htmlspecialchars_decode($row['band319'], ENT_QUOTES), htmlspecialchars_decode($row['band320'], ENT_QUOTES)];				 
}elseif ($day == "4"){
	$bands = ["filler", htmlspecialchars_decode($row['band401'], ENT_QUOTES), htmlspecialchars_decode($row['band402'], ENT_QUOTES), htmlspecialchars_decode($row['band403'], ENT_QUOTES), htmlspecialchars_decode($row['band404'], ENT_QUOTES), htmlspecialchars_decode($row['band405'], ENT_QUOTES), htmlspecialchars_decode($row['band406'], ENT_QUOTES),htmlspecialchars_decode($row['band407'], ENT_QUOTES), htmlspecialchars_decode($row['band408'], ENT_QUOTES),htmlspecialchars_decode($row['band409'], ENT_QUOTES), htmlspecialchars_decode($row['band410'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band411'], ENT_QUOTES), htmlspecialchars_decode($row['band412'], ENT_QUOTES), htmlspecialchars_decode($row['band413'], ENT_QUOTES), htmlspecialchars_decode($row['band414'], ENT_QUOTES), htmlspecialchars_decode($row['band415'], ENT_QUOTES), htmlspecialchars_decode($row['band416'], ENT_QUOTES),htmlspecialchars_decode($row['band417'], ENT_QUOTES), htmlspecialchars_decode($row['band418'], ENT_QUOTES),htmlspecialchars_decode($row['band419'], ENT_QUOTES), htmlspecialchars_decode($row['band420'], ENT_QUOTES)];
}elseif ($day == "5"){
	$bands = ["filler", htmlspecialchars_decode($row['band501'], ENT_QUOTES), htmlspecialchars_decode($row['band502'], ENT_QUOTES), htmlspecialchars_decode($row['band503'], ENT_QUOTES), htmlspecialchars_decode($row['band504'], ENT_QUOTES), htmlspecialchars_decode($row['band505'], ENT_QUOTES), htmlspecialchars_decode($row['band506'], ENT_QUOTES),htmlspecialchars_decode($row['band507'], ENT_QUOTES), htmlspecialchars_decode($row['band508'], ENT_QUOTES),htmlspecialchars_decode($row['band509'], ENT_QUOTES), htmlspecialchars_decode($row['band510'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band511'], ENT_QUOTES), htmlspecialchars_decode($row['band512'], ENT_QUOTES), htmlspecialchars_decode($row['band513'], ENT_QUOTES), htmlspecialchars_decode($row['band514'], ENT_QUOTES), htmlspecialchars_decode($row['band515'], ENT_QUOTES), htmlspecialchars_decode($row['band516'], ENT_QUOTES),htmlspecialchars_decode($row['band517'], ENT_QUOTES), htmlspecialchars_decode($row['band518'], ENT_QUOTES),htmlspecialchars_decode($row['band519'], ENT_QUOTES), htmlspecialchars_decode($row['band520'], ENT_QUOTES)];				 
}
$dbconnect->close();
$dbname= "stagepatch";
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
$showday= $week[$day];
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);

if ($mode=='full'){
 $query = mysqli_query($dbconnect, "SELECT * FROM `$showday`")
   or die (mysqli_error($dbconnect));
 $w=4;
 if ($user==$phantom){$w++;}
 echo "<table border='1'><tr>";
for ($x=1;$x<=$lineup;$x++){echo "<th colspan='$w'>Band $x - $bands[$x]</th>";}
 echo "</tr><tr>";

 if ($user=="foh"){
	for ($x=1;$x<=$lineup;$x++){
      echo"<td>Used</td><td>Name</td><td>Mic</td>";
      if ($phantom==$user){echo "<td>phantom</td>";}
      echo "<td>Foh CH</td>";} 
    echo "</tr>";
    while ($row = mysqli_fetch_array($query)) {
	  echo "<tr>";
      for ($x=1;$x<=$lineup;$x++){
	   $bandused="bandused".$x;
	   $bandname="bandname".$x;
	   $bandmic="bandmic".$x;
	   $notes="bandnotes".$x;
	   if ($phantom=='$user'){$bandphantom="bandphantom".$x;}
	   $bandfoh="bandfoh".$x;
	   if ($row[$bandused]==1){ echo "<td style='color:red'>&check;";}
	   else {echo "<td>";}
        echo "<td title='{$row[$notes]}'";
if (!empty($row[$notes])){
			 if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
			 else{
			 echo " style='color:yellow'";}
	}
	echo "><b>{$row[$bandname]}</b></td><td>{$row[$bandmic]}</td>";
	   if ($phantom==$user){
	      if ($row[$bandphantom]==1){ echo "<td style='color:red'>&check;";}
	   else {echo "<td>";}}
       echo "<td>{$row[$bandfoh]} </td>";
       }
       echo"<td>{$row['id']}</td></tr>";} 
    echo "</table>";


}elseif ($user=="mon"){
 for ($x=1;$x<=$lineup;$x++){
   echo"<td>Used</td><td>Name</td><td>Mic</td>";
   if ($phantom==$user){echo "<td>phantom</td>";}
   echo"<td> Mon CH</td>";
   } 
 echo "</tr>";
 while ($row = mysqli_fetch_array($query)) {
	
	echo "<tr>";
  for ($x=1;$x<=$lineup;$x++){
	$bandused="bandused".$x;
	$bandname="bandname".$x;
	$bandmic="bandmic".$x;
	$notes="bandnotes".$x;
	if ($phantom==$user){$bandphantom="bandphantom".$x;}
	$bandmon="bandmon".$x;
	if ($row[$bandused]==1){ echo "<td style='color:red'>&check;";}
	else {echo "<td>";}
    echo "<td title='{$row[$notes]}'";
if (!empty($row[$notes])){
			 if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
			 else{
			 echo " style='color:yellow'";}
	}
	echo "><b>{$row[$bandname]}</b></td><td>{$row[$bandmic]}</td>";
	if ($phantom==$user){
		if ($row[$bandphantom]==1){ echo "<td style='color:red'>&check;";}
	    else {echo "<td>";}}
    echo "<td>{$row[$bandmon]}</td>";
    }
  echo"<td>{$row['id']}</td></tr>";} 
 echo "</table>";

}elseif ($user=="patch"){
 for ($x=1;$x<=$lineup;$x++){
  echo"<td>Used</td><td>Name</td><td>Mic</td><td>phantom</td>";
  } 
 echo "</tr>";
 while ($row = mysqli_fetch_array($query)) {
     echo "<tr>";
  for ($x=1;$x<=$lineup;$x++){
	$bandused="bandused".$x;
	$bandname="bandname".$x;
	$bandmic="bandmic".$x;
	$bandphantom="bandphantom".$x;
	$notes="bandnotes".$x;
    if ($row[$bandused]==1){ echo "<td style='color:red'>&check;";}
	else {echo "<td>";}
     echo "<td title='{$row[$notes]}'";
	if (!empty($row[$notes])){
			 if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
			 else{
			 echo " style='color:yellow'";}
	}
	echo "><b>{$row[$bandname]}</b></td><td>{$row[$bandmic]}</td>";
	if ($row[$bandphantom]==1){ echo "<td style='color:red'>&check;";}
	else {echo "<td>";}
   }
   echo"<td>{$row['id']}</td></tr>";} 
 echo "</table>";}}

elseif ($mode=='soft'){
 if ($user===$phantom){
	 $phantomth="<th>+48v</th>";
 }else{$phantomth="";}
 echo "<div class='flex-container'>";
 if ($user=="foh"){
	for ($x=1; $x<=$lineup; $x++){
	  $bandused="bandused".$x;
	  $bandname="bandname".$x;
	  $bandmic="bandmic".$x;
	  $bandphantom="bandphantom".$x;
	  $bandch="bandfoh".$x;
	  $notes="bandnotes".$x;
	  echo "<div style='flex-basis:auto; flex-grow:1; flex-shrink:1;'><table border='1'><tr><th colspan=6>$bands[$x]</th></tr><tr>{$phantomth}<th>Ch</th><th>I/O</th><th> name</th><th>mic</th></tr>";
	  $stmt= "SELECT `$bandname`,`$bandmic`,`$bandphantom`,`$bandch`,`splitter`, `$notes` FROM `$showday` WHERE `$bandused`='1' ORDER BY `$bandch` ASC";
	  $query = mysqli_query($dbconnect, $stmt);
	  if ($user===$phantom){while ($row=  mysqli_fetch_array($query)){
		 $phantomrow="<td>";
         if ($row[$bandphantom]==1){$phantomrow="<td style='color:red'>&check;";}	 
		 echo "<tr>{$phantomrow}</td><td>{$row[$bandch]}</td><td>{$row['splitter']}</td><td title= '{$row[$notes]}'";
		 if (!empty($row[$notes])){
		echo " style='color:yellow'";
	}
	echo ">{$row[$bandname]}</td><td>{$row[$bandmic]}</td></tr>";}}
	  else {while ($row=  mysqli_fetch_array($query)){
		 echo "<tr><td>{$row[$bandch]}</td><td>{$row['splitter']}</td><td title= '{$row[$notes]}'";
		if (!empty($row[$notes])){
			 if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
			 else{
			 echo " style='color:yellow'";}
	}
	echo ">{$row[$bandname]}</td><td>{$row[$bandmic]}</td></tr>";}}
	  echo"</table></div>";}}
	  
elseif ($user=="mon"){
	for ($x=1; $x<=$lineup; $x++){
	  $bandused="bandused".$x;
	  $bandname="bandname".$x;
	  $bandmic="bandmic".$x;
	  $bandphantom="bandphantom".$x;
	  $bandch="bandmon".$x;
	  $notes="bandnotes".$x;
	  echo "<div style='flex-basis:auto; flex-grow:1; flex-shrink:1;'><table border='1'><tr><th colspan=6>$bands[$x]</th></tr><tr>{$phantomth}<th>Ch</th><th>I/O</th><th> name</th><th>mic</th></tr>";
	  $stmt= "SELECT `$bandname`,`$bandmic`,`$bandphantom`,`$bandch`,`splitter`, `$notes` FROM `$showday` WHERE `$bandused`='1' ORDER BY `$bandch` ASC";
	  $query = mysqli_query($dbconnect, $stmt);
	 if ($user===$phantom){while ($row=  mysqli_fetch_array($query)){
		 $phantomrow="<td>";
         if ($row[$bandphantom]==1){$phantomrow="<td style='color:red'>&check;";}	 
		 echo "<tr>{$phantomrow}</td><td>{$row[$bandch]}</td><td>{$row['splitter']}</td><td title= '{$row[$notes]}'";
		 if (!empty($row[$notes])){
			 if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
			 else{
			 echo " style='color:yellow'";}
	}
	echo ">{$row[$bandname]}</td><td>{$row[$bandmic]}</td></tr>";}}
	  else {while ($row=  mysqli_fetch_array($query)){
		 echo "<tr><td>{$row[$bandch]}</td><td>{$row['splitter']}</td><td title= '{$row[$notes]}'";
		 if (!empty($row[$notes])){
		echo " style='color:yellow'";
	}
	echo ">{$row[$bandname]}</td><td>{$row[$bandmic]}</td></tr>";}}
	  echo"</table></div>";}}

 echo "</div>";
}
 echo "<div ><br>Last Refreshed -".date("H:i:s")."</div>";
if ($mode=='guest'){
function guestpatch($x){ 
  $bandused="bandused".$x;
  $bandname="bandname".$x;
  $bandphantom="bandphantom".$x;
  $bandch="bandmon".$x;
  $notes="bandnotes".$x;
  global $showday;
  global $dbconnect;
  global $bands;
  $stmt= "SELECT `$bandname`,`$bandphantom`,`$bandch`,`splitter`, `$notes` FROM `$showday` WHERE `$bandused`='1' ORDER BY `splitter` ASC";
  $query = mysqli_query($dbconnect, $stmt);
  echo "<table border='1'><tr><th colspan='3'>$bands[$x]</th></tr><tr><th> House<br> Fanout</th><th>Band <br>Console</th><th>Channel <br> name</th></tr>";
  while ($row=  mysqli_fetch_array($query)){
	 echo "<tr><td ";
	 if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
	 echo "> {$row['splitter']} </td><td ";
	  if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
	 echo ">{$row[$bandch]}</td> <td title= '{$row[$notes]}'";
		 if (!empty($row[$notes])){
			 if(str_contains($row[$notes],'cut')){ echo "style='text-decoration: line-through; color: darkred;'";}
			 else{
		 echo " style='color:yellow'";}}
	echo "> {$row[$bandname]}</td></tr>";}
echo "</table";}

$dbname='stagepatch';
echo "<div class=flex-container style='align-items:start; justify-content:center;'>";
for ($x=1;$x<=$lineup;$x++){echo "<div style='flex-basis:auto;' padding=200px>".guestpatch($x)."</div><div style='flex: 1 0 50px;'></div>";}
echo "</div>";}
 ?>