<?php
include 'secrets.php';
$show=filter_var($_GET['showname'], FILTER_SANITIZE_SPECIAL_CHARS);
$mode = $_GET['mode'];
$value= filter_var($_GET['value'],FILTER_SANITIZE_NUMBER_INT);
$dbname = "stagepatchpreferences";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
if ($mode==='show'){
	$stmt = "UPDATE `showlist` SET `defaultshow`= '0'";
	$query = mysqli_query($dbconnect, $stmt);
	$stmt = "UPDATE `showlist` SET `defaultshow`= '1' WHERE `showname` = '$show'";
	$query = mysqli_query($dbconnect, $stmt);
	echo "$show has been made the default show for all users.";
}
if ($mode==='day'){
	$stmt = "UPDATE `showlist` SET `defaultday`= '$value' WHERE `showname` = '$show'";
	$query = mysqli_query($dbconnect, $stmt);
	echo "Day $value has been made the default day for $show";
}

?>