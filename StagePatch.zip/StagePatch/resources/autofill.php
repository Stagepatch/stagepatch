<?php
include 'arrays.php';
$dbname="stagepatch";
$show = htmlspecialchars($_GET["showname"]);	

if (isset($_GET['value'])){
$value=filter_var(trim($_GET['value']), FILTER_SANITIZE_SPECIAL_CHARS);
$id=filter_var($_GET['id'],FILTER_SANITIZE_NUMBER_INT);
$day=filter_var($_GET['day'],FILTER_SANITIZE_NUMBER_INT);
$prefix=$day*100;
$suffix = $prefix + $id;
$band="band{$suffix}";

if (isset($_GET['place'])){
	$place=filter_var($_GET['place'],FILTER_SANITIZE_NUMBER_INT);;
   $bandName="bandname{$place}";
   $bandMic="bandmic{$place}";
   $bandUsed="bandused{$place}";
   $band48v="bandphantom{$place}";}
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
$showday= $week[$day];
}

$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$stmt= "SELECT `name`,`defaultmic` from `$show` WHERE `id` = '$id'";
$query = mysqli_query($dbconnect, $stmt);
$row = mysqli_fetch_array($query);
$fill=$row[0];
$mic = $row[1];
if ($value==="true"){
   if (in_array($mic,$need48))	{
              $stmt = "UPDATE `$showday` SET  `$bandUsed`='1',`$bandName`= '$fill', `$bandMic`= '$mic', `$band48v`='1' WHERE `id` = '$id'";
   }else {$stmt = "UPDATE `$showday` SET `$bandUsed`='1',`$bandName`= '$fill', `$bandMic`= '$mic', `$band48v`='0' WHERE `id` = '$id'";}
$query = mysqli_query($dbconnect, $stmt);
echo "channel added";
 }
elseif ($value==="false"){
$stmt = "UPDATE `$showday` SET `$bandUsed`=NULL,`$bandName`= NULL, `$bandMic`= NULL, `$band48v`= NULL WHERE `id` = '$id'";
$query = mysqli_query($dbconnect, $stmt);
echo "channel removed";
 }
else {
	$dbname="stagepatchpreferences";
	$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
    $stmt = "UPDATE `showlist` SET `$band`= '$value' WHERE `showname` = '$show'";
    $query = mysqli_query($dbconnect, $stmt);
}
//echo $stmt;
?>