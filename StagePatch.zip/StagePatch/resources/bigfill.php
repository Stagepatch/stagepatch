<?php
include 'arrays.php';	
$value=filter_var($_GET['value'], FILTER_SANITIZE_SPECIAL_CHARS);
$id=filter_var($_GET['id'],FILTER_SANITIZE_NUMBER_INT);
$lineup=filter_var($_GET['lineup'],FILTER_SANITIZE_NUMBER_INT);
$showsize=filter_var($_GET['showsize'],FILTER_SANITIZE_NUMBER_INT);
$type=$_GET['type'];	
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
$showday= $week[$_GET['day']];
$dbname="stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);

if ($value == 'true'){
  $stmt= "SELECT `name`,`defaultmic` from `$show` WHERE `id` = '$id'";
  $query = mysqli_query($dbconnect, $stmt);
  $row = mysqli_fetch_array($query);
  $fill=$row[0];
  $mic = $row[1];
  $place=1;
   while ($place <= $lineup){
	 $bandMic="bandmic{$place}";
     $bandUsed="bandused{$place}";
     $band48v="bandphantom{$place}";
     $bandName="bandname{$place}";  
	 if (in_array($mic,$need48)){$stmt = "UPDATE `$showday` SET  `$bandUsed`='1',`$bandName`= '$fill', `$bandMic`= '$mic', `$band48v`='1' WHERE `id` = '$id'";
          }else {$stmt = "UPDATE `$showday` SET `$bandUsed`='1',`$bandName`= '$fill', `$bandMic`= '$mic', `$band48v`='0' WHERE `id` = '$id'";}
     $query = mysqli_query($dbconnect, $stmt);
    $place++;}
  echo "{$fill} filled to {$lineup} acts on {$showday}";
 }

else{
	$bandUsed="bandused{$id}";
	$bandfoh="bandfoh{$id}";
	$bandmon="bandmon{$id}";
	$stmt="SELECT `id`, `$bandUsed` from `$showday`";
    $query = mysqli_query($dbconnect, $stmt);
    $row = mysqli_fetch_array($query);
	if ($value=="house"){	
	  $x=1;
	  if ($type=="both"){
	    while ($x <= $showsize){
	        $stmt= "UPDATE `$showday` SET `$bandfoh`='$x', `$bandmon`='$x' WHERE `id`='$x' AND `$bandUsed`='1'";
	         $query = mysqli_query($dbconnect, $stmt);
	         $x++;}
			 echo "house patch applied to {$showday} - band {$id}";}
	  elseif ($type=="mon"){
	    while ($x <= $showsize){
	        $stmt= "UPDATE `$showday` SET `$bandmon`='$x' WHERE `id`='$x' AND `$bandUsed`='1'";
	         $query = mysqli_query($dbconnect, $stmt);
	         $x++;}
			 echo "house patch applied to {$showday} - band {$id} monitors only";}
	  elseif ($type=="foh"){
	    while ($x <= $showsize){
	        $stmt= "UPDATE `$showday` SET `$bandfoh`='$x' WHERE `id`='$x' AND `$bandUsed`='1'";
	         $query = mysqli_query($dbconnect, $stmt);
	         $x++;}
			 echo "house patch applied to {$showday} - band {$id} foh only";}
	  
	$stmt= "UPDATE `$showday` SET `$bandfoh`=NULL, `$bandmon`=NULL WHERE `$bandUsed`=NULL";
	$query = mysqli_query($dbconnect, $stmt);
	}
	
	elseif ($value=="clear"){
		if ($type=="both"){
		   $stmt= "UPDATE `$showday` SET `$bandfoh`=NULL, `$bandmon`=NULL";
		   echo "Patch cleared for {$showday}- band {$id}";}
		elseif ($type=="mon"){
		   $stmt= "UPDATE `$showday` SET  `$bandmon`=NULL";
		   echo "Patch cleared for {$showday}- band {$id} monitors only";}
		elseif ($type=="foh"){
		   $stmt= "UPDATE `$showday` SET `$bandfoh`=NULL";
		   echo "Patch cleared for {$showday}- band {$id} foh only";}
		
	$query = mysqli_query($dbconnect, $stmt);}
}
   if ($value=="soft"){	  
	  if ($type=="both"){
		  $stmt= "SET @i:=0; SET @j:=0;UPDATE `$showday` SET `$bandfoh`= @i:=(@i+1), `$bandmon`=  @j:=(@j+1)WHERE `$bandUsed`='1'";
	      $query = mysqli_multi_query($dbconnect, $stmt);
	      $stmt= "UPDATE `$showday` SET `$bandfoh`=NULL, `$bandmon`=NULL WHERE `$bandUsed`=NULL";
	      $query = mysqli_query($dbconnect, $stmt);
	      echo "soft patch applied to {$showday} - band {$id}";}
	   elseif ($type=="mon"){
	      $stmt= "SET @j:=0;UPDATE `$showday` SET `$bandmon`=  @j:=(@j+1)WHERE `$bandUsed`='1'";
	      $query = mysqli_multi_query($dbconnect, $stmt);
	      $stmt= "UPDATE `$showday` SET `$bandmon`=NULL WHERE `$bandUsed`=NULL";
	      $query = mysqli_query($dbconnect, $stmt);
	      echo "soft patch applied to {$showday} - band {$id} monitors only ";}
	   elseif ($type=="foh"){	  
          $stmt= "SET @i:=0; UPDATE `$showday` SET `$bandfoh`= @i:=(@i+1)WHERE `$bandUsed`='1'";
	      $query = mysqli_multi_query($dbconnect, $stmt);
	      $stmt= "UPDATE `$showday` SET `$bandfoh`=NULL WHERE `$bandUsed`=NULL";
	      $query = mysqli_query($dbconnect, $stmt);
	      echo "soft patch applied to {$showday} - band {$id} foh only";}}

?>