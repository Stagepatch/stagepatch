<?php
$day=$_GET['day'];
$lineup=$_GET['lineup'];
$show=$_GET['showname'];
$showsize=$_GET['showsize'];
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
$showday= $week[$day];
$servername = "localhost";
$username = "root";
$password = "";
$dbname='stagepatch';
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, "SELECT * FROM `$showday`");
$i=1;
$names=[''];
$mics=[''];
$fohch=[''];
$monch=[''];
$notes=[''];

while ($row = mysqli_fetch_array($query)) {
	$x=1;
	while ($x<=$lineup){
	  $names[]=htmlspecialchars_decode($row["bandname".$x], ENT_NOQUOTES);
	  $notes[]=htmlspecialchars_decode($row["bandnotes".$x], ENT_NOQUOTES);
	  $mics[]=$row["bandmic".$x];
	  $fohch[]= $row["bandfoh".$x];
	  $monch[]=$row["bandmon".$x];
	  $x++;}
	$i++;}

function autofill($names,$mics,$fohch,$monch,$notes){
$x=1;
echo"<script async>var values=[];";
while ($x < count($names)) {
    echo"values.push('{$names[$x]}', '{$mics[$x]}','{$fohch[$x]}','{$monch[$x]}', '{$notes[$x]}');";
	$x++;}
echo "boxes= document.getElementsByName('bandfill');
for(var x=0; x < boxes.length; x++) {boxes[x].value = values[x];}</script>triggered";
}

autofill($names,$mics,$fohch,$monch,$notes);

?>