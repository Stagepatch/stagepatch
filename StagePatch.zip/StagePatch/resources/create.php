<!DOCTYPE html><html><!--create show page--><head><link rel="icon" href="logo.ico"></head><body>
<?php $version='feb';
      include 'banner.php';
      include 'style.php';
	 
$dbname = "stagepatchpreferences";
$dbconnect = mysqli_connect($servername, $username, $password, $dbname);
if ($dbconnect->connect_error) {
  die("Connection failed: " . $dbconnect->connect_error);
}

if (isset($_POST["showsize"])){
$errors="";
$show = filter_var(trim($_POST["showname"]), FILTER_SANITIZE_SPECIAL_CHARS);
$showsize = filter_var($_POST["showsize"],FILTER_SANITIZE_NUMBER_INT);
$lineup = filter_var($_POST["lineup"],FILTER_SANITIZE_NUMBER_INT);
$days = filter_var($_POST["days"],FILTER_SANITIZE_NUMBER_INT);
$loggedin= filter_var(trim($_POST["loggedin"]), FILTER_SANITIZE_SPECIAL_CHARS);
$query=$dbconnect->query("SELECT showname FROM showlist");
$showlist=mysqli_fetch_array($query);


if (($lineup==="")or ($lineup<1)){ $errors=$errors."invalid number of bands given- must be an integer below 20<br>";}
if ($lineup >20) {$errors=$errors."thats too many bands- 20 per day is the max supported. {$lineup} given<br>";}
if ($showsize===""){$errors=$errors."invalid number of channels given<br>";}
if (($days==="") or ($days<1)){$errors=$errors."invalid number of bands given- must be an integer below 5<br>";}
if ($days > 5){$errors=$errors."your show is too long- maximum supported show length is 5 days<br>";}
if ($show===""){$errors=$errors."no show name given<br>";}
if (is_array($showlist) && in_array($show, $showlist)){$errors=$errors."a show already exists with this name<br>";}
if (strlen($show)>20){$errors=$errors."Show name is too long- maximum length 20 characters. <br>";}
}

echo "<div id='create' style='text-align: right; width:350px;'><form method='post'><label for 'loggedin' > Selected User Profile:</label><select id='loggedin' name='loggedin'>";
 

$showusers = $dbconnect->query("SELECT name FROM users");
while($user = mysqli_fetch_array($showusers)) { 
  echo("<option value='$user[0]'>$user[0]</option>");  
 }
$dbconnect->close();
echo"
  </select><br> <label for='showname' >Show Name:</label><input type='text' id='showname' name='showname' value='{$show}'><br>
<label for='showsize' >Select number of channels:</label><select id='showsize' name='showsize'><option value='32'>32 ch</option><option value='48'>48 ch</option><option value='56'>56 ch</option><option value='64'>64 ch</option><option value='96'>96 ch</option><option value='128'>128 ch</option></select><br>
<label for 'days'>number of show days</label>
<select id='days' name='days'><option value='1'>1</option><option value='2'>2</option><option value='3'>3</option><option value='4'>4</option><option value='5'>5</option></select><br>
<label for='lineup'>number of acts per day:</label>
<input type='text' id='lineup' name='lineup' value='{$lineup}'><br>
 <input type='submit' value='Create'></form></div>
<div style='float:left;'>{$errors} ";


//--create show script-->
if (isset($_POST["showsize"])){
if ($errors===""){
echo "All input parameters apear to be valid";
$dbname = "stagepatch";
$dbconnect = mysqli_connect($servername, $username, $password, $dbname);
if ($dbconnect->connect_error) {
  die("Connection failed: " . $dbconnect->connect_error);
}
$sql = "select 1 from `$show` LIMIT 1";

if($sql === FALSE)
{
   echo "this show name already exists";
}
else
{ //set line in showlist
$show = htmlspecialchars($_POST["showname"]);
$showsize = $_POST["showsize"];
$dbname = "stagepatchpreferences";
$loggedin = $_POST["loggedin"];	
$dbconnect = mysqli_connect($servername, $username, $password, $dbname);
echo "<p>Creating your show- this may take some time</p>";
if ($dbconnect->connect_error) {
die("Connection failed: " . $dbconnect->connect_error);}

$stmt="SELECT * FROM `users` WHERE `name` = '$loggedin'";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, $stmt);
$row = mysqli_fetch_array($query);
$redsize=$row['redsize'];
$bluesize=$row['bluesize'];
$greensize=$row['greensize'];
$yellowsize=$row['yellowsize'];
$orangesize=$row['orangesize'];
$brownsize=$row['brownsize'];
$blacksize=$row['blacksize'];
$whitesize=$row['whitesize'];
$greysize=$row['greysize'];
$purplesize=$row['purplesize'];
$fohcol=$row['fohcol'];
$moncol=$row['moncol'];

$dbconnect->close();

$dbname = "stagepatchpreferences";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = "INSERT INTO showlist (owner, showname, showsize, days, numbands, redsize, bluesize, greensize, yellowsize, orangesize, blacksize, brownsize, greysize, whitesize, purplesize, fohcol, moncol, defaultday, defaultband, defaultshow, version)
  VALUES ('$loggedin', '$show', '$showsize', '$days', '$lineup', '$redsize', '$bluesize', '$greensize', '$yellowsize', '$orangesize','$blacksize', '$brownsize', '$greysize', '$whitesize', '$purplesize', '$fohcol', '$moncol', '1', '1', '0', '$version')";
 if (!mysqli_query($dbconnect, $query)) {
        die('Showlist Error <br>');
    } else {
      echo "<p>Show Added to Showlist </p>";
    }

if ($dbconnect->connect_error) {
die("Connection failed: " . $dbconnect->connect_error);}
$dbconnect->close();}
   
$dbname = "stagepatch";
$dbconnect = mysqli_connect($servername, $username, $password, $dbname);
$sql = "CREATE TABLE `$show` (
id INT(3) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(20),
splitter INT(2),
fohio VARCHAR(10),
monio VARCHAR(10),
fohch INT(3) UNSIGNED,
monch INT(3) UNSIGNED,
48v BOOLEAN,
defaultmic VARCHAR(20),
defaulthardware VARCHAR(30),
cable INT(3) UNSIGNED,
risercount INT(1),
satcol VARCHAR(10),
satch INT(2),
ysatcol VARCHAR(10),
ysatch INT(2)
)";


if ($dbconnect->query($sql) === TRUE) {
  echo "<p>Show: `$show` created successfully</p>";
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
for ($y=1;$y<= $days;$y++){
	$showday = $week[$y];
	$dbconnect = mysqli_connect($servername, $username, $password, $dbname);
    $sql = "CREATE TABLE IF NOT EXISTS `$showday` (id INT(3) UNSIGNED AUTO_INCREMENT PRIMARY KEY, splitter INT(2))";
	$dbconnect->query($sql);
	if ($dbconnect->query($sql) === TRUE) {
	  echo "<p>{$showday} table created</p> ";} 
      else {
        echo "Error creating table: " . $dbconnect->error;}}  
	echo "<p>preparing to populate databases</p>";
$dbconnect->close();
} 
echo" <div id='populate' name='populate'></div>";
echo "<p>populating databases...</p>";
$dbconnect = mysqli_connect($servername, $username, $password, $dbname);
for ($x=1;$x <= $showsize;$x++) {
$sql = "INSERT INTO `$show` (splitter, fohio, monio, fohch, monch, risercount)
VALUES ($x, $x, $x, $x, $x, 1);";
if (mysqli_query($dbconnect, $sql)) {
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($dbconnect);
}}

for ($y=1; $y<= $days; $y++){
 $showday= htmlspecialchars("{$show}- day {$y}");
  echo "<p>populating $showday</p>";
for ($x=1;$x <= $showsize; $x++) {
$sql = "INSERT INTO `$showday` (splitter) VALUES ($x);";
if (mysqli_query($dbconnect, $sql)) {
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($dbconnect);
}}} 
   for ($y=1;$y <= $days; $y++){
  $showday= htmlspecialchars("{$show}- day {$y}");
    for ($x=1;$x<= $lineup; $x++){
       $addused = "ALTER TABLE `$showday` ADD COLUMN bandused$x BOOLEAN";
       $addname= "ALTER TABLE `$showday` ADD COLUMN bandname$x VARCHAR(20)";
       $addmic= "ALTER TABLE `$showday` ADD COLUMN bandmic$x VARCHAR(20)";
       $addphantom ="ALTER TABLE `$showday` ADD COLUMN bandphantom$x BOOLEAN";
       $addfoh = "ALTER TABLE `$showday` ADD COLUMN bandfoh$x INT(3)";
       $addmon = "ALTER TABLE `$showday` ADD COLUMN bandmon$x INT(3)";
       $addnote = "ALTER TABLE `$showday` ADD COLUMN bandnotes$x TEXT";
       if (mysqli_query($dbconnect, $addused)){
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($dbconnect);
}
       mysqli_query ($dbconnect, $addname);
       mysqli_query ($dbconnect, $addmic);
       mysqli_query ($dbconnect, $addphantom);
       mysqli_query ($dbconnect, $addfoh);
       mysqli_query ($dbconnect, $addmon);
       mysqli_query ($dbconnect, $addnote);
	   }} 

echo "<p>Show creation complete</p><button onClick='window.top.location.reload();'>Continue</button> ";
}}
?>

</div></body></html>