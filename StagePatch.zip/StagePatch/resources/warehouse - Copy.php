<?php
include 'arrays.php';
include "style.php";
$show=$_GET['showname'];
$page=$_GET['page'];
$dbname = "stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
if ($dbconnect->connect_error) {die("Database connection failed: " . $dbconnect->connect_error);}

if($page=="rack"){
echo "<h3>Rack patch for {$show}</h3>
<table border='1'>
<tr><th colspan='16'>Stage Box Patch</th></tr><tr>
    <td>Name</td>
  <td>Split</td>
  <td> FOH io</td>
  <td>Mon io </td>
  <td>Satalite</td>
  <td>Y Satalite</td>
  </tr>";
$query = mysqli_query($dbconnect, "SELECT * FROM `$show`")
   or die (mysqli_error($dbconnect));
while ($row = mysqli_fetch_array($query)) {
  echo "<tr>
    <td>{$row['name']}</td>
    <td>{$row['splitter']}</td>
    <td>{$row['fohio']}</td>
    <td>{$row['monio']} </td>
    <td style='background-color:{$row["satcol"]}'>{$row['satcol']}{$row['satch']}</td>
    <td style='background-color:{$row["ysatcol"]}'>{$row['ysatcol']}{$row['ysatch']}</td>
    </tr>\n";
}
echo "</table>"; }

elseif ($page=="mic"){ echo "<h3>Mic prep list for {$show}</h3>";
echo "<br><h3>Mics and DIs list: </h3><div class='flex-container' style='align-items:stretch; justify-content:space-between;' width='100%'><div style='flex-basis:auto;'><h4>default Mics/DIs:</h4>";
$generic=[];
foreach ($mic_list as &$value){
	$query = mysqli_query($dbconnect, "SELECT * FROM `$show`");
	$count=0;
	$i=0;
    while ($row = mysqli_fetch_array($query)){
         if ($row['defaultmic']== $value){
	     $count= $count + $row['risercount'];
		 $generic[$i]=$value;}
		 $i++;}
		    if ($count != 0){
			    echo "{$value} x {$count}<br>";}
				}
												
$dbname = "stagepatchpreferences";
$stmt="SELECT * FROM `showlist` WHERE `showname`='$show'";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, $stmt);
$row = mysqli_fetch_array($query);
$days=$row['days'];
$lineup=$row['numbands'];
$bands1 = ["filler", htmlspecialchars_decode($row['band101'], ENT_QUOTES), htmlspecialchars_decode($row['band102'], ENT_QUOTES), htmlspecialchars_decode($row['band103'], ENT_QUOTES), htmlspecialchars_decode($row['band104'], ENT_QUOTES), htmlspecialchars_decode($row['band105'], ENT_QUOTES), htmlspecialchars_decode($row['band106'], ENT_QUOTES),htmlspecialchars_decode($row['band107'], ENT_QUOTES), htmlspecialchars_decode($row['band108'], ENT_QUOTES),htmlspecialchars_decode($row['band109'], ENT_QUOTES), htmlspecialchars_decode($row['band110'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band111'], ENT_QUOTES), htmlspecialchars_decode($row['band112'], ENT_QUOTES), htmlspecialchars_decode($row['band113'], ENT_QUOTES), htmlspecialchars_decode($row['band114'], ENT_QUOTES), htmlspecialchars_decode($row['band115'], ENT_QUOTES), htmlspecialchars_decode($row['band116'], ENT_QUOTES),htmlspecialchars_decode($row['band117'], ENT_QUOTES), htmlspecialchars_decode($row['band118'], ENT_QUOTES),htmlspecialchars_decode($row['band119'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
$bands2 = ["filler", htmlspecialchars_decode($row['band201'], ENT_QUOTES), htmlspecialchars_decode($row['band202'], ENT_QUOTES), htmlspecialchars_decode($row['band203'], ENT_QUOTES), htmlspecialchars_decode($row['band204'], ENT_QUOTES), htmlspecialchars_decode($row['band205'], ENT_QUOTES), htmlspecialchars_decode($row['band206'], ENT_QUOTES),htmlspecialchars_decode($row['band207'], ENT_QUOTES), htmlspecialchars_decode($row['band208'], ENT_QUOTES),htmlspecialchars_decode($row['band209'], ENT_QUOTES), htmlspecialchars_decode($row['band220'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band211'], ENT_QUOTES), htmlspecialchars_decode($row['band212'], ENT_QUOTES), htmlspecialchars_decode($row['band213'], ENT_QUOTES), htmlspecialchars_decode($row['band214'], ENT_QUOTES), htmlspecialchars_decode($row['band215'], ENT_QUOTES), htmlspecialchars_decode($row['band216'], ENT_QUOTES),htmlspecialchars_decode($row['band217'], ENT_QUOTES), htmlspecialchars_decode($row['band218'], ENT_QUOTES),htmlspecialchars_decode($row['band219'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
$bands3 = ["filler", htmlspecialchars_decode($row['band301'], ENT_QUOTES), htmlspecialchars_decode($row['band302'], ENT_QUOTES), htmlspecialchars_decode($row['band303'], ENT_QUOTES), htmlspecialchars_decode($row['band304'], ENT_QUOTES), htmlspecialchars_decode($row['band305'], ENT_QUOTES), htmlspecialchars_decode($row['band306'], ENT_QUOTES),htmlspecialchars_decode($row['band307'], ENT_QUOTES), htmlspecialchars_decode($row['band308'], ENT_QUOTES),htmlspecialchars_decode($row['band309'], ENT_QUOTES), htmlspecialchars_decode($row['band310'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band311'], ENT_QUOTES), htmlspecialchars_decode($row['band312'], ENT_QUOTES), htmlspecialchars_decode($row['band313'], ENT_QUOTES), htmlspecialchars_decode($row['band314'], ENT_QUOTES), htmlspecialchars_decode($row['band315'], ENT_QUOTES), htmlspecialchars_decode($row['band316'], ENT_QUOTES),htmlspecialchars_decode($row['band317'], ENT_QUOTES), htmlspecialchars_decode($row['band318'], ENT_QUOTES),htmlspecialchars_decode($row['band319'], ENT_QUOTES), htmlspecialchars_decode($row['band320'], ENT_QUOTES)];				 
$bands4 = ["filler", htmlspecialchars_decode($row['band401'], ENT_QUOTES), htmlspecialchars_decode($row['band402'], ENT_QUOTES), htmlspecialchars_decode($row['band403'], ENT_QUOTES), htmlspecialchars_decode($row['band404'], ENT_QUOTES), htmlspecialchars_decode($row['band405'], ENT_QUOTES), htmlspecialchars_decode($row['band406'], ENT_QUOTES),htmlspecialchars_decode($row['band407'], ENT_QUOTES), htmlspecialchars_decode($row['band408'], ENT_QUOTES),htmlspecialchars_decode($row['band409'], ENT_QUOTES), htmlspecialchars_decode($row['band410'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band411'], ENT_QUOTES), htmlspecialchars_decode($row['band412'], ENT_QUOTES), htmlspecialchars_decode($row['band413'], ENT_QUOTES), htmlspecialchars_decode($row['band414'], ENT_QUOTES), htmlspecialchars_decode($row['band415'], ENT_QUOTES), htmlspecialchars_decode($row['band416'], ENT_QUOTES),htmlspecialchars_decode($row['band417'], ENT_QUOTES), htmlspecialchars_decode($row['band418'], ENT_QUOTES),htmlspecialchars_decode($row['band419'], ENT_QUOTES), htmlspecialchars_decode($row['band420'], ENT_QUOTES)];
$bands5 = ["filler", htmlspecialchars_decode($row['band501'], ENT_QUOTES), htmlspecialchars_decode($row['band502'], ENT_QUOTES), htmlspecialchars_decode($row['band503'], ENT_QUOTES), htmlspecialchars_decode($row['band504'], ENT_QUOTES), htmlspecialchars_decode($row['band505'], ENT_QUOTES), htmlspecialchars_decode($row['band506'], ENT_QUOTES),htmlspecialchars_decode($row['band507'], ENT_QUOTES), htmlspecialchars_decode($row['band508'], ENT_QUOTES),htmlspecialchars_decode($row['band509'], ENT_QUOTES), htmlspecialchars_decode($row['band510'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band511'], ENT_QUOTES), htmlspecialchars_decode($row['band512'], ENT_QUOTES), htmlspecialchars_decode($row['band513'], ENT_QUOTES), htmlspecialchars_decode($row['band514'], ENT_QUOTES), htmlspecialchars_decode($row['band515'], ENT_QUOTES), htmlspecialchars_decode($row['band516'], ENT_QUOTES),htmlspecialchars_decode($row['band517'], ENT_QUOTES), htmlspecialchars_decode($row['band518'], ENT_QUOTES),htmlspecialchars_decode($row['band519'], ENT_QUOTES), htmlspecialchars_decode($row['band520'], ENT_QUOTES)];				 

$bands = ["filler", $bands1, $bands2, $bands3, $bands4, $bands5];
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
$dbname = "stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
for ($x=1;$x<=$days;$x++){
	echo "</div><div style='flex-basis:auto; flex-shink:0;'><H4>Substitutions for day {$x}</h4>";
	$todaysbands=$bands[$x];
	$showday= $week[$x];
	for ($y=1;$y <= $lineup;$y++){
		$countarray=[];
		foreach ($mic_list as &$value){
		if ($value !=" "){	
	      $count=0;
		  $bandmic="bandmic{$y}";
		  $i=0;
		   $query = mysqli_query($dbconnect, "SELECT * FROM `$showday`");
          while ($result = mysqli_fetch_array($query)){
               if (($result[$bandmic]==$value) and ((isset($generic[$i]))and ($generic[$i]!= $result[$bandmic]))){
	           $count++;}
			   $i++;}
		          if ($count != 0){
			      $countarray[]="{$value} x {$count}";
		}}}	   
		if (count($countarray)>0){
		echo "<br><u>{$todaysbands[$y]}</u><br>";
		foreach ($countarray as &$item){echo "$item <br>";}}	   
		}}
	
echo "</div><div style='flex-basis:auto; flex-shink:0;'><h3>Stands list: </h3>";
foreach ($standlist as &$value){
	if ($value!='NA'){
	$query = mysqli_query($dbconnect, "SELECT * FROM `$show`");
	$count=0;
    while ($row = mysqli_fetch_array($query)){
         if ($row['defaulthardware']== $value){
	     $count= $count + $row['risercount'];}}
		    if ($count != 0){
			    echo "{$value} x ";
	            echo $count;
            	echo "<br>";}}}
				

echo "</div><div style='flex-basis:auto; flex-shink:0;'><h3>Mic cable list: </h3>
<table border='1'><tr><th> cable</th><th>qty</th></tr>
<tr><td>Y combiners </td><td> ";
$query = mysqli_query($dbconnect, "SELECT * FROM `$show`");
	$count=0;
    while ($row = mysqli_fetch_array($query)){
         if ($row['ysatch']>= 1){
	         $count++;}}
	     echo $count;
	     echo "</td></td>";
	$i=0;	 
    foreach ($cable_lengths as &$value){
		if (isset($value)){
		$count=0;
		$query = mysqli_query($dbconnect, "SELECT * FROM `$show`");
		while ($row = mysqli_fetch_array($query)){
         if ($row['cable']== $value){
	     $count= $count + $row['risercount'];}}
		    if ($count != 0){
		echo "<tr style ='background-color:{$cable_cols[$i]}'><td>{$value}</td><td>{$count}</td></tr> ";}}
			$i++;}
	echo "</table></div></div>";
}
elseif ($page=="sat"){
echo "	<h3>Satalite/Remote Boxes:</h3>";
 $boxes=array('"red"', '"blue"', '"green"', '"yellow"', '"orange"', '"brown"', '"purple"', '"grey"', '"white"', '"black"');
 $format=array("red", "blue", "green", "yellow", "orange", "brown", "purple", "grey", "white", "black");
 for ($x=0; $x < count($boxes);$x++)
 {echo "<table border='1' style='float: left; background-color:{$format[$x]}'><tr><th>$format[$x]</th></tr>";
 $stmt="SELECT * FROM `$show` WHERE satcol  = $boxes[$x] OR ysatcol = $boxes[$x] ORDER BY satch, ysatch";
 $query = mysqli_query($dbconnect, $stmt)
   or die (mysqli_error($dbconnect));
 while ($row = mysqli_fetch_array($query)) {
	 echo "<tr> <td>";
	 echo "{$row['satch']}</td>";
	 echo "<td>{$row['name']}</td></tr>";}  
 echo"</table>";}}?>