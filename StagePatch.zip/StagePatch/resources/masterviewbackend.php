<!DOCTYPE html>
<html>
<!--master view backendpage-->
<head>

</head>
<body>
<style>tr { line-height: 15px; }
}</style>
<?php
include 'arrays.php';
include 'style.php';
$day=$_GET['day'];
if ($day=="undefined"){
    $day=1;}
$dbname = "stagepatchpreferences";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, "SELECT * FROM showlist WHERE showname = '$show'");
$row = mysqli_fetch_array($query);
$days=$row['days'];
$lineup= $row['numbands'];


if ($day == "1"){
	$bands = ["filler", htmlspecialchars_decode($row['band101'], ENT_QUOTES), htmlspecialchars_decode($row['band102'], ENT_QUOTES), htmlspecialchars_decode($row['band103'], ENT_QUOTES), htmlspecialchars_decode($row['band104'], ENT_QUOTES), htmlspecialchars_decode($row['band105'], ENT_QUOTES), htmlspecialchars_decode($row['band106'], ENT_QUOTES),htmlspecialchars_decode($row['band107'], ENT_QUOTES), htmlspecialchars_decode($row['band108'], ENT_QUOTES),htmlspecialchars_decode($row['band109'], ENT_QUOTES), htmlspecialchars_decode($row['band110'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band111'], ENT_QUOTES), htmlspecialchars_decode($row['band112'], ENT_QUOTES), htmlspecialchars_decode($row['band113'], ENT_QUOTES), htmlspecialchars_decode($row['band114'], ENT_QUOTES), htmlspecialchars_decode($row['band115'], ENT_QUOTES), htmlspecialchars_decode($row['band116'], ENT_QUOTES),htmlspecialchars_decode($row['band117'], ENT_QUOTES), htmlspecialchars_decode($row['band118'], ENT_QUOTES),htmlspecialchars_decode($row['band119'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
}elseif ($day == "2"){
	$bands = ["filler", htmlspecialchars_decode($row['band201'], ENT_QUOTES), htmlspecialchars_decode($row['band202'], ENT_QUOTES), htmlspecialchars_decode($row['band203'], ENT_QUOTES), htmlspecialchars_decode($row['band204'], ENT_QUOTES), htmlspecialchars_decode($row['band205'], ENT_QUOTES), htmlspecialchars_decode($row['band206'], ENT_QUOTES),htmlspecialchars_decode($row['band207'], ENT_QUOTES), htmlspecialchars_decode($row['band208'], ENT_QUOTES),htmlspecialchars_decode($row['band209'], ENT_QUOTES), htmlspecialchars_decode($row['band220'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band211'], ENT_QUOTES), htmlspecialchars_decode($row['band212'], ENT_QUOTES), htmlspecialchars_decode($row['band213'], ENT_QUOTES), htmlspecialchars_decode($row['band214'], ENT_QUOTES), htmlspecialchars_decode($row['band215'], ENT_QUOTES), htmlspecialchars_decode($row['band216'], ENT_QUOTES),htmlspecialchars_decode($row['band217'], ENT_QUOTES), htmlspecialchars_decode($row['band218'], ENT_QUOTES),htmlspecialchars_decode($row['band219'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
}elseif ($day == "3"){
	$bands = ["filler", htmlspecialchars_decode($row['band301'], ENT_QUOTES), htmlspecialchars_decode($row['band302'], ENT_QUOTES), htmlspecialchars_decode($row['band303'], ENT_QUOTES), htmlspecialchars_decode($row['band304'], ENT_QUOTES), htmlspecialchars_decode($row['band305'], ENT_QUOTES), htmlspecialchars_decode($row['band306'], ENT_QUOTES),htmlspecialchars_decode($row['band307'], ENT_QUOTES), htmlspecialchars_decode($row['band308'], ENT_QUOTES),htmlspecialchars_decode($row['band309'], ENT_QUOTES), htmlspecialchars_decode($row['band310'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band311'], ENT_QUOTES), htmlspecialchars_decode($row['band312'], ENT_QUOTES), htmlspecialchars_decode($row['band313'], ENT_QUOTES), htmlspecialchars_decode($row['band314'], ENT_QUOTES), htmlspecialchars_decode($row['band315'], ENT_QUOTES), htmlspecialchars_decode($row['band316'], ENT_QUOTES),htmlspecialchars_decode($row['band317'], ENT_QUOTES), htmlspecialchars_decode($row['band318'], ENT_QUOTES),htmlspecialchars_decode($row['band319'], ENT_QUOTES), htmlspecialchars_decode($row['band320'], ENT_QUOTES)];				 
}elseif ($day == "4"){
	$bands = ["filler", htmlspecialchars_decode($row['band401'], ENT_QUOTES), htmlspecialchars_decode($row['band402'], ENT_QUOTES), htmlspecialchars_decode($row['band403'], ENT_QUOTES), htmlspecialchars_decode($row['band404'], ENT_QUOTES), htmlspecialchars_decode($row['band405'], ENT_QUOTES), htmlspecialchars_decode($row['band406'], ENT_QUOTES),htmlspecialchars_decode($row['band407'], ENT_QUOTES), htmlspecialchars_decode($row['band408'], ENT_QUOTES),htmlspecialchars_decode($row['band409'], ENT_QUOTES), htmlspecialchars_decode($row['band410'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band411'], ENT_QUOTES), htmlspecialchars_decode($row['band412'], ENT_QUOTES), htmlspecialchars_decode($row['band413'], ENT_QUOTES), htmlspecialchars_decode($row['band414'], ENT_QUOTES), htmlspecialchars_decode($row['band415'], ENT_QUOTES), htmlspecialchars_decode($row['band416'], ENT_QUOTES),htmlspecialchars_decode($row['band417'], ENT_QUOTES), htmlspecialchars_decode($row['band418'], ENT_QUOTES),htmlspecialchars_decode($row['band419'], ENT_QUOTES), htmlspecialchars_decode($row['band420'], ENT_QUOTES)];
}elseif ($day == "5"){
	$bands = ["filler", htmlspecialchars_decode($row['band501'], ENT_QUOTES), htmlspecialchars_decode($row['band502'], ENT_QUOTES), htmlspecialchars_decode($row['band503'], ENT_QUOTES), htmlspecialchars_decode($row['band504'], ENT_QUOTES), htmlspecialchars_decode($row['band505'], ENT_QUOTES), htmlspecialchars_decode($row['band506'], ENT_QUOTES),htmlspecialchars_decode($row['band507'], ENT_QUOTES), htmlspecialchars_decode($row['band508'], ENT_QUOTES),htmlspecialchars_decode($row['band509'], ENT_QUOTES), htmlspecialchars_decode($row['band510'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band151'], ENT_QUOTES), htmlspecialchars_decode($row['band512'], ENT_QUOTES), htmlspecialchars_decode($row['band513'], ENT_QUOTES), htmlspecialchars_decode($row['band514'], ENT_QUOTES), htmlspecialchars_decode($row['band515'], ENT_QUOTES), htmlspecialchars_decode($row['band516'], ENT_QUOTES),htmlspecialchars_decode($row['band517'], ENT_QUOTES), htmlspecialchars_decode($row['band518'], ENT_QUOTES),htmlspecialchars_decode($row['band519'], ENT_QUOTES), htmlspecialchars_decode($row['band520'], ENT_QUOTES)];				 
}
$dbconnect->close();

$dbname = "stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);

if ($dbconnect->connect_error) {
  die("Database connection failed: " . $dbconnect->connect_error);
}

?>

<table border="1" align="left"  >
<tr><th colspan="16">Festival Patch</th></tr><tr>
  <td>ID</td>
  <td>Name</td>
  <td>Split</td>
  <td> FOH io</td>
  <td>Mon io </td>
  <td>FOH ch</td>
  <td>Mon ch</td>
  <td>48v</td>
  <td>defaultmic </td>
  <td>defaulthardware</td>
  <td>cable </td>
  <td>riser count</td>
  <td>satcol</td>
  <td>satch </td>
  <td>ysatcol</td>
  <td>ysatch</td>
</tr>

<?php
$query = mysqli_query($dbconnect, "SELECT * FROM `$show`")
   or die (mysqli_error($dbconnect));

while ($row = mysqli_fetch_array($query)) {
	$needle=$row['cable'];
	$x= array_search($needle, $cable_lengths);
	$cable=$cable_cols[$x];
  echo
   "<tr>
    <td>{$row['id']}</td>
    <td><b>{$row['name']}</b></td>
    <td>{$row['splitter']}</td>
    <td>{$row['fohio']}</td>
    <td>{$row['monio']} </td>
    <td>{$row['fohch']}</td>
    <td>{$row['monch']}</td>";
	if ($row['48v']==1){ echo "<td style='color:red'>&check;";}
	else {echo "<td>";}
    echo "</td>
    <td>{$row['defaultmic']} </td>
    <td>{$row['defaulthardware']}</td>
    <td style='background-color:$cable'>{$row['cable']} </td>
	<td>{$row['risercount']}</td>";
	echo "<td style='background-color:{$row["satcol"]}'>{$row['satcol']}</td>
    <td style='background-color:{$row["satcol"]}'>{$row['satch']} </td>
    <td style='background-color:{$row["ysatcol"]}'>{$row['ysatcol']}</td>
    <td style='background-color:{$row["ysatcol"]}'>{$row['ysatch']}</td>
   </tr>\n";
}
$dbconnect->close();
?>
</table>



<div style="overflow-x:auto; white-space: nowrap">
<table border=1 >
<tr>
<?php
if (isset($_POST['page'])){
   $page=$_POST['page'];}
   else { $page=1;}
if ($page!=0){
$dbname = "stagepatchpreferences";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, "SELECT * FROM showlist WHERE showname = '$show'");
$row = mysqli_fetch_row($query);

$dbconnect->close();
$x=1;
while ($x<=$lineup){
	echo "<th colspan='6'>Band $x - $bands[$x]</th>";
	$x+=1;
}
echo "</tr><tr>";

$x=1;
while ($x<=$lineup){
  echo"<td>Used</td><td>Name</td><td>Mic</td><td>phantom</td><td>Foh CH</td><td> Mon CH</td>";
  $x+=1;
  } 
echo "</tr>";

$dbname= "stagepatch";
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
$showday= $week[$day];
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, "SELECT * FROM `$showday`")
   or die (mysqli_error($dbconnect));

while ($row = mysqli_fetch_array($query)) {
	$x=1;
	echo "<tr>";
  while ($x<=$lineup){
	$bandused="bandused".$x;
	$bandname="bandname".$x;
	$bandmic="bandmic".$x;
	$bandphantom="bandphantom".$x;
	$bandfoh="bandfoh".$x;
	$bandmon="bandmon".$x;
	
 
	if ($row[$bandused]==1){ echo "<td style='color:red'>&check;";}
	else {echo "<td>";}
    echo "<td><b>{$row[$bandname]}</b></td>
    <td>{$row[$bandmic]}</td>";
	if ($row[$bandphantom]==1){ echo "<td style='color:red'>&check;";}
	else {echo "<td>";}
    echo "<td>{$row[$bandfoh]} </td>
   <td>{$row[$bandmon]}</td>";
   $x+=1;
   }
echo"<td>{$row['id']}</td></tr>";} 
echo "</table><div style='float: left;'><br>Last Refreshed -".date("H:i:s")."</div>";
}
?>

</body></html>