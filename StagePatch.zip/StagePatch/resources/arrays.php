<?php
include 'secrets.php';
$dbname = "stagepatchpreferences";
if (isset($_GET['showname'])){
$show=$_GET['showname'];}
$boxlist= array ("red", "blue", "green", "yellow", "orange", "brown", "purple", "grey", "white", "black");
$standlist= array ("NA", "Short Boom", "Tall Boom",  "Tall Straight RoundBase","Short Boom RoundBase", "Tall Boom RoundBase", "clip-on", "LP-Claw", "Zed-Bar", "Cab Grabber", "SE guitaRF");
$DPA_mounts= ["drum", "violin", "cello", "guitar", "piano", "universal"];
$mic_list = ["Bands Own"];

//DIs
$DI= [" ", "DI boxes:", "XLR out", "Sans amp", "Generic Passive DI", "Generic Active DI", "Emo passive", "Emo Stereo", "BSS AR133", "KT DN100", "KT DN200", "micro DI", "Radial J48", "Radial ProDI", "Radial Pro48", "Radial ProAV", "Radial ProUSB", "PC bal box"];


//mics
$C =[" C5"," C214", " C414"," C451", " C1000", " C3000"];
$D = [" D5", " D7", " D12", " D112", " D330", " D440",];
$AKG= [" ","AKG:"];
$AKG = array_merge($AKG, $C, $D);


$Audiotechnica = [" ","Audiotechnica:", "AE3000", "AT2020", " AT4033a", " AT4040"," AT4041"," AT4050", "ATM250DE (dyn)", "ATM250DE (con)", "ATM350", "AE2500 (dyn)", "AE2500 (con)"];
$Audix=[" ","Audix:", " D2", " D4", " D6", " fireball", " micro-D", " micro-HP", " ADX20ip", " I5", " OM2", " OM3", " OM5", " OM6", " OM7", " OM11", " VX5", " VX11"];
$Beyer=[" "," Beyerdynamic:", " m88", " m201"];
$DPA=[" ","DPA:", " 2011", " 4011", " 4061", " 4099", " D-facto", " D-facto wireless"];
$Neumann=[" ","Neumann:", " KMS104", " KMS105", " KMS104 wireless", " KMS105 wireless"];



$SM =[" SM57"," SM58", "SM58 switch", " SM81"," SM87"," SM91"];
$Beta = ["beta 52a", " Beta 56"," Beta 57"," Beta 57a", " Beta 58a"," Beta 87a", " Beta 87c"," Beta 91", " Beta 91a", " Beta 98D", "Beta 98 H/C"];
$KSM = [" KSM8", " KSM9", " KSM32", "KSM109", " KSM137",];
$Shure_Wireless= [" SM58 Wireless", " Beta 58 Wireless", " Beta 98 wireless", " KSM8 wireless", " KSM9 wireless"];
$Shure=[" ","Shure:"];
$Shure=array_merge($Shure, $SM, $Beta, $KSM, $Shure_Wireless);



$MD=[ " MD406", " MD421", " MD441", " MD504", "ME64"];
$e600=[" e602"," e604", " e606/609", " e614",];
$e800=[" e835", " e845"];
$e900=[" e901", " e902", " e904", " e905", " e906", " e914", " e935"," e945", " e965"];
$Senn_Wireless=[" e935 -wireless"," e945 -wireless"," e965 -wireless"," e835 -wireless"," 845 -wireless"];
$Sennheiser=[" ","Sennheiser:"];
$Sennheiser= array_merge($Sennheiser, $MD, $e600, $e800, $e900, $Senn_Wireless);

$SE =[" ","SE Electronics:", " V-kick", " V-beat", " V7", " V7 wireless", ];

$brand_list = [$DI, $AKG, $Audiotechnica, $Audix, $Beyer, $DPA, $Neumann, $Shure, $Sennheiser, $SE];
foreach ($brand_list as &$value) {
$mic_list = array_merge($mic_list, $value);}

//Lists for asigning hardware
$in =[" e901", " SM91", " Beta 91", " Beta 91a"];
$clip = [" e904", " e604", " MD504", " Beta 98D"];
$need48=["Generic Active DI", "BSS AR133", "KT DN100", "KT DN200", "micro DI", "Radial J48", "Radial Pro48", " C5"," C214", " C414"," C451", " C1000", " C3000", "AT2020", " AT4033a", " AT4040"," AT4041"," AT4050",  "ATM250DE (con)", "ATM350",  "AE2500 (con)"," micro-D", " micro-HP", " ADX20ip"," 2011", " 4011", " 4061", " 4099", " D-facto"," KMS104", " KMS105"," SM81", " SM87"," SM91"," Beta 87a", " Beta 87c"," Beta 91", " Beta 91a", " Beta 98D", "Beta 98 H/C", " KSM8", " KSM9", " KSM32", " KSM137"," e614"," e901","e914"," e965", "ME64", "KSM109", "AE3000"];


//cables
if (isset($_GET['showname'])){
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, "SELECT `owner` FROM `showlist` WHERE `showname` = '$show'");
$row = mysqli_fetch_array($query);
$owner= $row[0];
$query = mysqli_query($dbconnect, "SELECT * FROM `users` WHERE `name` = '$owner'");
$row = mysqli_fetch_array($query);
$cable_lengths = array($row['len1'], $row['len2'], $row['len3'], $row['len4'], $row['len5'], $row['len6'], $row['len7'], $row['len8'], $row['len9'], $row['len10']); 
$cable_cols = array($row['col1'], $row['col2'], $row['col3'], $row['col4'], $row['col5'], $row['col6'], $row['col7'], $row['col8'], $row['col9'], $row['col10']);
}
?>