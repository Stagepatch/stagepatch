<html><style>#View tr:nth-child(odd){background-color:#778899}tr:nth-child(even){background-color:#d3d3d3}tr:nth-child(odd){background-color:#778899}body{background-color:LightGray;color:#000;border:0;margin:4px;padding:0}.flex-container{display:flex;flex-direction:row;flex-wrap:wrap;justify-content:left}td{text-align:right}table{float:left;margin:3px}
tr:hover {
  background: lightblue;
}</style></html><?php
include 'secrets.php';
?>
