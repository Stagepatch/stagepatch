
<?php

include 'secrets.php';
include 'arrays.php';
$dbname = "stagepatchpreferences";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
if (isset($_GET['showname'])){$show=filter_var(trim($_GET["showname"]), FILTER_SANITIZE_SPECIAL_CHARS);}
if (isset($_GET["loggedin"])){
$loggedin = filter_var(trim($_GET["loggedin"]), FILTER_SANITIZE_SPECIAL_CHARS);
}


if (isset($_GET['size'])){
$col = $_GET["col"];
$size=$_GET['size'];
if (isset($_GET['mode'])){
	$mode=$_GET['mode'];}
if (isset($_GET['no'])){
	 $no= $_GET['no'];
if ($col==='length'){$box="len".$no;}
   elseif  ($col==='col'){ $box="col".$no;}}
  elseif ($col==="black"){$box = "blacksize";}
    elseif ($col==="brown"){$box = "brownsize";}
    elseif ($col==="red"){$box = "redsize";}
    elseif ($col==="orange"){$box = "orangesize";}
    elseif ($col==="yellow"){$box = "yellowsize";}
    elseif ($col==="green"){$box = "greensize";}
    elseif ($col==="blue"){$box = "bluesize";}
    elseif ($col==="purple"){$box = "purplesize";}
    elseif ($col==="grey"){$box = "greysize";}
    elseif ($col==="white"){$box = "whitesize";}
    elseif ($col==="foh"){$box = "fohcol";}
    elseif ($col==="mon"){$box = "moncol";}
    elseif ($col==="phantom"){$box = "48v";}

if (isset($show)){
$stmt = "UPDATE `showlist` SET `$box`= '$size' WHERE `showname` = '$show'";
//echo $stmt;
} else {
	if (isset($loggedin)){
	  $stmt = "UPDATE `users` SET `$box`= '$size' WHERE `name` = '$loggedin'";
          //echo $stmt;	
		  }
}
if (isset ($mode)){if($mode=="riser"){
$dbname = "stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$stmt="UPDATE `$show` SET `risercount` = '$size' WHERE `satcol` = '$col'"; }}
//echo $stmt;
$query = mysqli_query($dbconnect, $stmt);

echo "Properties updated -".date("H:i:s");
}
if (isset($_GET['value'])){
$value=$_GET['value'];
$id=filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);
$cat=filter_var(trim($_GET['cat']), FILTER_SANITIZE_SPECIAL_CHARS);
$day=filter_var($_GET['day'], FILTER_SANITIZE_NUMBER_INT);

if ($value=="true"){
$value="1"; }
if ($value=="false"){
$value="0"; }

$dbname="stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
if (isset($show)){
if ($day==69){
   $stmt = "UPDATE `$show` SET `$cat`= '$value' WHERE `id` = '$id'";
   if ($cat==="defaultmic") {
	   if (in_array($value,$need48)){
		   $stmt = "UPDATE `$show` SET `$cat`= '$value', `48v`='1' WHERE `id` = '$id'";
		   } else {
			   $stmt = "UPDATE `$show` SET `$cat`= '$value', `48v`='0' WHERE `id` = '$id'";}
		$query = mysqli_query($dbconnect, $stmt);	   
		
		if (in_array($value,$DI)== TRUE){$stmt = "UPDATE `$show` SET `defaulthardware`= 'NA' WHERE `id` = '$id'";}
            elseif  (in_array($value,$in)== TRUE){$stmt = "UPDATE `$show` SET `defaulthardware`= 'NA' WHERE `id` = '$id'";}
	            elseif  (in_array($value,$clip)== TRUE){$stmt = "UPDATE `$show` SET `defaulthardware`= 'clip-on' WHERE `id` = '$id'";;}	
        $query = mysqli_query($dbconnect, $stmt);  
	
}
   
			
}
else {
		$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
    $showday= $week[$day];
	
		if (str_contains($cat,'bandmic')) {
			
		$bandphantom= str_replace('bandmic','bandphantom',$cat);
		
	if (in_array($value,$need48)){
		
		   $stmt = "UPDATE `$showday` SET `$cat`= '$value', `$bandphantom`='1' WHERE `id` = '$id'";
		   } else {
			   $stmt = "UPDATE `$showday` SET `$cat`= '$value', `$bandphantom`='0' WHERE `id` = '$id'";}
		//echo $stmt;
		$query = mysqli_query($dbconnect, $stmt);	}
	
	
	$stmt = "UPDATE `$showday` SET `$cat`= '$value' WHERE `id` = '$id'";}
//echo $stmt;
$query = mysqli_query($dbconnect, $stmt);
echo "Patch updated -".date("H:i:s");}}
?>
