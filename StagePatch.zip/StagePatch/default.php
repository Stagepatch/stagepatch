<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="resources/logo.ico">
<!--- User default page -->
</head>

<body>
<?php include 'resources/banner.php';
      include 'resources/style.php';
	 
 ?>
<style>
table {
  float: left;
  margin: 10px;
}

</style>
<div class="container" id="grad1" style=' width: 100%;'>
  <div class="top-left"> <img src='resources/stagepatchlogotransparant.png'></div>
  <div class="top-right"><H1>
<?php
$dbconnect=mysqli_connect($servername, $username, $password);
$query=$dbconnect->query("SHOW DATABASES LIKE 'stagepatchpreferences'");
$exist=mysqli_fetch_array($query);
if (is_array($exist)){
$dbname = "stagepatchpreferences";
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET["showname"])) {
   $show = htmlspecialchars($_GET["showname"]);
   echo "$show";
}else{$query= $conn->query("SELECT `showname` FROM `showlist` WHERE `defaultshow` = '1'");
$row=mysqli_fetch_array($query);
if (isset($row['showname'])){
$show =$row['showname'];
echo $show;}
else{echo "No Show Selected";}
}

echo "</H1></div>
  <div class='bottom-right'>
  <form  method='get'>
  <select id='showname' name='showname' onchange='this.form.submit()'>
  <option value='null'>select a show</option>";

$showtables = $conn->query("SELECT `showname` FROM `showlist`");

 while($table = mysqli_fetch_array($showtables)) { 
  echo("<option value='$table[0]'>$table[0]</option>");  
}

//$conn->close();
echo "</select></form></div></div>";
$showtables = $conn->query("SELECT `showname` FROM `showlist`");
if (is_array(mysqli_fetch_array($showtables))==0){
	echo "It apears no shows are currently on this server, please contact your systems administrator (ERROR U001)" ;
}

if (isset($show)){
  $stmt="SELECT `fohcol`,`moncol`, `48v`, `days`, `defaultday` FROM `showlist` WHERE `showname`='$show'";
  $dbconnect=mysqli_connect($servername,$username,$password,$dbname);
  $query = mysqli_query($dbconnect, $stmt);
  $row = mysqli_fetch_row($query);
  $fohcol= $row['0'];
  $moncol= $row['1'];
  $phantom = $row['2'];
  $days = $row['3'];
  $defaultday=$row['4'];
  $day=$defaultday;}
function DayMenu ($user, $mode){
	global $days;
	echo "<select id='page$user' name='page$user' onchange='viewchange(this.value, `$user`, `$mode`)'>
          <option value = 'null'>Select day</option>";
    for ($x=1;$x <=$days;$x++){
         echo "<option value=$x>View Day- $x</option>";
 } 
     echo "</select>";}  


echo "<div id='selectshow' STYLE='color:black;";
if(isset($show)) {echo "display: none;";} else {echo "display: block;";} 
echo "'><h3> Select a show to begin </h3></div><div class='topnav' id='myTopnav' STYLE='";
if(isset($show)) {echo "display: block;";} else {echo "display: none;";}
echo "'><div class='dropdown'><button class='dropbtn'>FoH<i class='fa fa-caret-down'></i></button>
    <div class='dropdown-content'>
      <a class='tablinks' onclick='openUser(event, `FOH`), viewchange(`$day`, `foh`, `full`)'>FoH Full View</a>
      <a class='tablinks' onclick='openUser(event, `FOH2`), viewchange(`$day`, `foh`, `soft`)'>FoH Soft Patch</a>
    </div></div>
  <div class='dropdown'><button class='dropbtn'>Mons<i class='fa fa-caret-down'></i>    </button><div class='dropdown-content'>
      <a class='tablinks' onclick='openUser(event, `Mons`), viewchange(`$day`, `mon`, `full`)'>Monitors Full View</a>
      <a class='tablinks' onclick='openUser(event, `Mons2`), viewchange(`$day`, `mon`, `soft`)'>Monitors Soft Patch</a>
	  <a class='tablinks' onclick='openUser(event, `Mons3`), viewchange(`$day`, `mon`, `guest`)'>Guest Console Patch</a>
    </div></div>
  <a class='tablinks' onclick='openUser(event, `Patch`), viewchange(`$day`, `patch`, `full`)'>Patch</a>
  <div class='dropdown'>
    <button class='dropbtn'>Warehouse
      <i class='fa fa-caret-down'></i>
    </button>
   <div class='dropdown-content'>
      <a class='tablinks' onclick='openUser(event, `Warehouse`), warehouse(`rack`)'>Rack Patch</a>
      <a class='tablinks' onclick='openUser(event, `Warehouse`), warehouse(`sat`)'>Satalite Boxes</a>
      <a class='tablinks' onclick='openUser(event, `Warehouse`), warehouse(`mic`)'>Mic Prep</a>
    </div></div>"; 
	}else{echo "</div></div><h3 color='black'>It apears no shows are currently on this server, please contact your systems administrator (ERROR U001)</h3>";}
	?>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">&#9776;</a>

</div>
<div id="FOH" class="tabcontent"   STYLE="display: none; color:black; text-align: left; background-color: <?php echo "$fohcol"; ?>; color:white;">
<?php DayMenu("foh","full");?></div>
<div id="FOH2" class="tabcontent"   STYLE="display: none; color:black; text-align: left; background-color:  <?php echo "$fohcol"; ?>;color:white;">
<?php DayMenu("foh","soft");?></div>
<div id="Mons" class="tabcontent" STYLE="display: none; color:black; text-align: left; background-color: <?php echo "$moncol"; ?>;color:white;">
<?php DayMenu("mon", "full");?></div>
<div id="Mons2" class="tabcontent" STYLE="display: none; color:black; text-align: left; background-color:  <?php echo "$moncol"; ?>;color:white;">
<?php DayMenu("mon", "soft");?></div>
<div id="Mons3" class="tabcontent" STYLE="display: none; color:black; text-align: left; background-color:  <?php echo "$moncol"; ?>;color:white;">
<?php  DayMenu("mon", "guest"); ?></div>
<div id="Patch" class="tabcontent" STYLE="display: none; color:black; text-align: left;">
<?php DayMenu("patch", "full");?></div>
<div id="Warehouse" class="tabcontent" STYLE="display: none; color:black; text-align: left;"></div>

<div id='userviewbox'></div>
<script>

/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}

function openUser(evt, user) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(user).style.display = "block";
  evt.currentTarget.className += " active";
}

function viewchange(day, user, view) {
 // if (day == "") {
//	day=1/
 //   return;	}
    
        document.getElementById("userviewbox").innerHTML = "<iframe src='pages/"+user+".php?showname=<?php echo $show;?>&phantom=<?php echo $phantom; ?>&mode="+view+"&page="+day+"' style=' height: 2000px; width: 100%;' frameBorder='0'> </iframe>";
      }	
	  
function warehouse(tool) {
     document.getElementById("userviewbox").innerHTML = "<iframe src='resources/warehouse.php?showname=<?php echo $show;?>&page="+tool+"' style=' height: 2000px; width: 100%;' frameBorder='0'> </iframe>";
      }		  
</script>
</body></html>