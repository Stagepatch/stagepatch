<!DOCTYPE html>

<!-- Master default page -->
<link rel="icon" href="resources/logo.ico">
<?php 
 include 'resources/secrets.php';   
$dbconnect=mysqli_connect($servername, $username, $password);
$query=$dbconnect->query("SHOW DATABASES LIKE 'stagepatchpreferences'");
$exist=mysqli_fetch_array($query);
if (is_array($exist)){
include 'resources/style.php';
include 'resources/banner.php';
echo "<html>
<head><link rel='icon' href='resources/logo.ico'></head><body>
<div id='grad1'>
<div class='container'>
  <div id='grad1'>
   <div class='top-left'> <img src='resources/stagepatchlogotransparant.png'></div>
  <div class='top-right'><H1>";
$dbname = "stagepatchpreferences";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo "<p style='color : black;'> It apears the database has not yet been set up on this server. Please use set up tool below (ERROR M001)</p><input type='button' onclick='location.href=`resources/setup.php`;' value='set up' />";
}
if (isset($_GET["showname"])) {
   $show = htmlspecialchars($_GET["showname"]);
   echo "$show";
   $query= $conn->query("SELECT `showname`, `defaultday` FROM `showlist` WHERE `showname` = '$show'");
$row=mysqli_fetch_array($query);
$day=$row['defaultday'];
   
}else{$query= $conn->query("SELECT `showname`, `defaultday` FROM `showlist` WHERE `defaultshow` = '1'");
$row=mysqli_fetch_array($query);
if (isset($row['showname'])){
$show =$row['showname'];
$day = $row['defaultday'];
echo $show;}
else{echo "No Show Selected";
$show='';}
}
echo "<H1></div> <div class='bottom-right'>
<form method='GET'>
<select id='showname' name='showname' onchange='this.form.submit()'>
  <option value='null'>select a show</option>";

$showtables = $conn->query("SELECT `showname` FROM `showlist`");
 while($table = mysqli_fetch_array($showtables)) { 
  echo("<option value='$table[0]'>$table[0]</option>");  
 }

echo"</select></form></div></div>";
 
$query =$conn->query("SELECT `name` FROM `users`");
$checkuser=mysqli_fetch_array($query);
if (is_array($checkuser)==0){
	echo "<p style='color : black;'> It apears the database has not yet been set up on this server. Please use set up tool below (ERROR M001)</p><input type='button' onclick='location.href=`resources/setup.php`;' value='set up' />";
}
echo "<div class='topnav' id='myTopnav'>
<a class='tablinks' onclick='openUser(event, `Files`), filesview()'>Create Show</a>
<a class='tablinks' onclick='openUser(event, `Users`)'>User Preferences</a>";
if ($show!=''){echo "
<a class='tablinks' onclick='openUser(event, `View`), masterview({$day})'>Master View</a>
<a class='tablinks' onclick='openUser(event, `Edit`)'>Edit Show</a>";}
echo "<a href='javascript:void(0);' class='icon' onclick='myFunction()'>&#9776;</a></div>
<div id='mainbox' STYLE='color:black; text-align: left; clear:both;'></div>
<div id='Files' class='tabcontent' STYLE='display:none; color:black; text-align: left;'>
<div id='filesbox'></div></div>
 <div id='Edit' height=100% class='tabcontent' STYLE='display: none; color:black; text-align: left; clear:both;'>";

$stmt="SELECT `days` FROM showlist WHERE showname = '$show'";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, $stmt);
$row = mysqli_fetch_row($query);
$days=$row[0];
echo 
"<select id='page' name='page' onchange='editview(this.value)'>
  <option value='0'>choose what to edit</option>
  <option value='69'>Edit Generic Patch</option>";
 
  $x=1;
  while ($x <= $days){
  echo "<option value=$x>Edit Day- $x</option>";
  $x++;} 
  
  echo "</select>
<div name='editviewbox' id='editviewbox' class='flex-container' style=' height: auto;'>
</div></div>
 
<div id='Users' class='tabcontent' STYLE='display:none; color:black; text-align: left;'>
<iframe src='pages/users.php?showname=$show' style='height: 2000px; width:100%;'> </iframe></div>

<div id='View' class='tabcontent' STYLE='display:none; color:black; text-align: left;'>
<select id='page' name='page' onchange='masterview(this.value)'>
<option value=0>select day</option>";

  $x=1;
  while ($x <= $days){
  echo "<option value='$x'>View Day- $x</option>";
  $x++;} 

  echo "</select><b>Currently viewing Day -{$day}</b>
<div id='masterviewbox' STYLE=' color:black; text-align: left; clear:both;'></div></div>";
}else {echo "It apears the database has not yet been set up on this server. Please use set up tool below (ERROR M001)<br><a href='resources/setup.php'>RUN FIRST TIME SET UP</a>";}?>

<script>
function pageview(page) {
  if (page == "") {
    document.getElementById("mainbox").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("mainbox").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","pages/"+page+".php?showname=<?php echo $show;?>",true);
    xmlhttp.send();
  }
}


/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}

function openUser(evt, user) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(user).style.display = "block";
  evt.currentTarget.className += " active";
}

function masterview(day) {
  if (day == "") {
	day=1;
    return;	}
    
        document.getElementById("masterviewbox").innerHTML = "<iframe src='resources/masterviewbackend.php?showname=<?php echo $show;?>&day="+day+"' style=' height: 2000px; width: 100%;' frameBorder='0'> </iframe>";
      }




function editview(day) {
  if (day == "") {
	day=69;
    return;	}
    
        document.getElementById("editviewbox").innerHTML = "<iframe src='pages/edit.php?showname=<?php echo $show;?>&page="+day+"' style=' height: 2000px; width: 100%;' frameBorder='0'> </iframe>";
      }
	  
function filesview(page){
	document.getElementById("filesbox").innerHTML = "'<iframe src='resources/create.php' style=' height: 2000px; width: 100%;' frameBorder='0'> </iframe>";
}	  

</script>
</body></html>