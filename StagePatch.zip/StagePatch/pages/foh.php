<!DOCTYPE html>
<html>
<head><style>tr { line-height: 20px; }
}</style></head>
<?php 
include '../resources/style.php';
$show=$_GET['showname'];
$phantom=$_GET['phantom'];
$page=$_GET['page'];
$mode=$_GET['mode'];
echo "<b>Currently viewing Day -{$page} as FOH</b>";
echo "<body><div class='flex-container'>";
if ($mode==='full'){
$dbname = "stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);

if ($dbconnect->connect_error) {
  die("Database connection failed: " . $dbconnect->connect_error);
}
if ($phantom=='foh'){$x=5;}else{$x=4;}
echo "<div style='flex-basis:auto; flex-shink:0;'><table border='1' align='left'>
<tr><th colspan='$x'>Festival Patch</th></tr>
<tr><td>Name</td>
  <td> FOH io</td>
  <td> FOH ch</td>";
 if ($phantom=="foh"){ echo " <td>48v</td>";}
echo "  <td>defaultmic </td>
  </tr>";

$query = mysqli_query($dbconnect, "SELECT * FROM `$show`")
   or die (mysqli_error($dbconnect));

while ($row = mysqli_fetch_array($query)) {
  echo
   "<tr>
    <td>{$row['name']}</td>
    <td>{$row['fohio']}</td>
    <td>{$row['fohch']}</td>";
if ($phantom=="foh"){ 
	  if ($row['48v']==1){ echo "<td style='color:red'>&check;";}
	  else {echo "<td>";}
      echo "</td>";}
 echo "<td>{$row['defaultmic']} </td>
   </tr>\n";
}
echo "</table></div>";}?>
<div id="bands_div" style="flex-basis:20%; flex-grow:2; overflow-x:auto; white-space: nowrap;"></div></div>
</body>
<script>
var myVar = setInterval(bandsView, 10000);



function bandsView()
   {
      var xmlhttp;
      if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
        }
      else
        {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
      xmlhttp.onreadystatechange=function()
        {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
           document.getElementById("bands_div").innerHTML=xmlhttp.responseText;
          }
        }
      xmlhttp.open("POST","../resources/bandview.php?showname=<?php echo $show;?>&page=<?php echo $page;?>&user=foh&phantom=<?php echo $phantom; ?>&mode=<?php echo $mode;?>",true);
      xmlhttp.send();
   }
   
var myVar = setInterval(bandsView, 10000);

bandsView(); 




</script>
</html>