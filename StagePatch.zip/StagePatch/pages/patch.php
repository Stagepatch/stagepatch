<!DOCTYPE html>
<html>
<head><style>tr { line-height: 20px; }
}</style></head>
<body>
<?php 
include '../resources/style.php';
include '../resources/arrays.php';
$show=$_GET['showname'];
$phantom=$_GET['phantom'];
$page=$_GET['page'];
$mode=$_GET['mode'];
$dbname = "stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);

if ($dbconnect->connect_error) {
  die("Database connection failed: " . $dbconnect->connect_error);
}

echo "<b>Currently viewing Day -{$page} as Patch Engineer</b><br>";
if ($phantom=="foh"){echo "FoH is phantom master <br>";}
if ($phantom=="mon"){echo "Monitors is phantom master <br>";}
$cableshow='no';
$query = mysqli_query($dbconnect, "SELECT * FROM `$show`")
   or die (mysqli_error($dbconnect));
   while ($row = mysqli_fetch_array($query)) {
   if (!empty($row['cable'])){$cableshow='yes';}}
?>
<div class='flex-container'><div style='flex-basis:auto; flex-shink:0;'><table border='1'  align="left">
<tr><th colspan='11'>Festival Patch</th></tr>
  <td>Split</td>
  <td>Name</td>
  <td>48v</td>
  <td>defaultmic </td>
  <td>defaulthardware</td>
<?php if ($cableshow=='yes') {echo "<td>cable </td>";}   ?>
<!--  <td>doubleriser</td>
  <td>satcol</td>  -->
  <td>satch </td>
<!--  <td>ysatcol</td> -->
  <td>ysatch</td>
</tr>

<?php


$query = mysqli_query($dbconnect, "SELECT * FROM `$show`")
   or die (mysqli_error($dbconnect));
while ($row = mysqli_fetch_array($query)) {
	$needle=$row['cable'];
	$x= array_search($needle, $cable_lengths);
	$cable=$cable_cols[$x];
  echo
   "<tr>
    <td>{$row['splitter']}</td>
    <td>{$row['name']}</td>";
	if ($row['48v']==1){ echo "<td style='color:red'>&check;";}
	else {echo "<td>";}
    echo "</td>
    <td>{$row['defaultmic']} </td>
    <td>{$row['defaulthardware']}</td>";
    if ($cableshow=='yes') {echo "<td style='background-color:$cable'>{$row['cable']} </td>";}
    echo " <!--	<td>{$row['risercount']}</td>
    <td style='background-color:{$row["satcol"]}'>{$row['satcol']}</td> -->
    <td style='background-color:{$row["satcol"]}'>{$row['satch']} </td>
<!--    <td style='background-color:{$row["ysatcol"]}'>{$row['ysatcol']}</td> -->
    <td style='background-color:{$row["ysatcol"]}'>{$row['ysatch']}</td>
   </tr>\n";

}

?>

</table></div>
<div id="bands_div" style="flex-basis:20%; flex-grow:2;overflow-x:auto; white-space: nowrap; "></div></div>
</body>
<script>
var myVar = setInterval(bandsView, 10000);



function bandsView()
   {
      var xmlhttp;
      if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
        }
      else
        {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
      xmlhttp.onreadystatechange=function()
        {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
          {
           document.getElementById("bands_div").innerHTML=xmlhttp.responseText;
          }
        }
      xmlhttp.open("POST","../resources/bandview.php?showname=<?php echo $show;?>&page=<?php echo $page;?>&user=patch&phantom=<?php echo $phantom; ?>&mode=<?php echo $mode;?>",true);
      xmlhttp.send();
   }
   
var myVar = setInterval(bandsView, 10000);

bandsView(); 




</script>
</html>