<!DOCTYPE html>
<html><head><style>
table { float: left;
border: 1px solid;
//  margin: 3px;
  }
  tr {height: 30px;} 
</style></head><body>
<?php 
include '../resources/arrays.php';
include '../resources/style.php';
$day=$_GET['page'];
$dbname = "stagepatchpreferences";
$stmt="SELECT * FROM `showlist` WHERE `showname`='$show'";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, $stmt);
$row = mysqli_fetch_array($query);
$days=$row['days'];
$lineup = $row['numbands'];
$bigwidth = $lineup*7; 
$showsize=$row['showsize'];
$defaultshow=$row['defaultshow'];
$defaultday=$row['defaultday'];
if ($day == "1"){
	$bands = ["filler", htmlspecialchars_decode($row['band101'], ENT_QUOTES), htmlspecialchars_decode($row['band102'], ENT_QUOTES), htmlspecialchars_decode($row['band103'], ENT_QUOTES), htmlspecialchars_decode($row['band104'], ENT_QUOTES), htmlspecialchars_decode($row['band105'], ENT_QUOTES), htmlspecialchars_decode($row['band106'], ENT_QUOTES),htmlspecialchars_decode($row['band107'], ENT_QUOTES), htmlspecialchars_decode($row['band108'], ENT_QUOTES),htmlspecialchars_decode($row['band109'], ENT_QUOTES), htmlspecialchars_decode($row['band110'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band111'], ENT_QUOTES), htmlspecialchars_decode($row['band112'], ENT_QUOTES), htmlspecialchars_decode($row['band113'], ENT_QUOTES), htmlspecialchars_decode($row['band114'], ENT_QUOTES), htmlspecialchars_decode($row['band115'], ENT_QUOTES), htmlspecialchars_decode($row['band116'], ENT_QUOTES),htmlspecialchars_decode($row['band117'], ENT_QUOTES), htmlspecialchars_decode($row['band118'], ENT_QUOTES),htmlspecialchars_decode($row['band119'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
}elseif ($day == "2"){
	$bands = ["filler", htmlspecialchars_decode($row['band201'], ENT_QUOTES), htmlspecialchars_decode($row['band202'], ENT_QUOTES), htmlspecialchars_decode($row['band203'], ENT_QUOTES), htmlspecialchars_decode($row['band204'], ENT_QUOTES), htmlspecialchars_decode($row['band205'], ENT_QUOTES), htmlspecialchars_decode($row['band206'], ENT_QUOTES),htmlspecialchars_decode($row['band207'], ENT_QUOTES), htmlspecialchars_decode($row['band208'], ENT_QUOTES),htmlspecialchars_decode($row['band209'], ENT_QUOTES), htmlspecialchars_decode($row['band220'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band211'], ENT_QUOTES), htmlspecialchars_decode($row['band212'], ENT_QUOTES), htmlspecialchars_decode($row['band213'], ENT_QUOTES), htmlspecialchars_decode($row['band214'], ENT_QUOTES), htmlspecialchars_decode($row['band215'], ENT_QUOTES), htmlspecialchars_decode($row['band216'], ENT_QUOTES),htmlspecialchars_decode($row['band217'], ENT_QUOTES), htmlspecialchars_decode($row['band218'], ENT_QUOTES),htmlspecialchars_decode($row['band219'], ENT_QUOTES), htmlspecialchars_decode($row['band120'], ENT_QUOTES)];
}elseif ($day == "3"){
	$bands = ["filler", htmlspecialchars_decode($row['band301'], ENT_QUOTES), htmlspecialchars_decode($row['band302'], ENT_QUOTES), htmlspecialchars_decode($row['band303'], ENT_QUOTES), htmlspecialchars_decode($row['band304'], ENT_QUOTES), htmlspecialchars_decode($row['band305'], ENT_QUOTES), htmlspecialchars_decode($row['band306'], ENT_QUOTES),htmlspecialchars_decode($row['band307'], ENT_QUOTES), htmlspecialchars_decode($row['band308'], ENT_QUOTES),htmlspecialchars_decode($row['band309'], ENT_QUOTES), htmlspecialchars_decode($row['band310'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band311'], ENT_QUOTES), htmlspecialchars_decode($row['band312'], ENT_QUOTES), htmlspecialchars_decode($row['band313'], ENT_QUOTES), htmlspecialchars_decode($row['band314'], ENT_QUOTES), htmlspecialchars_decode($row['band315'], ENT_QUOTES), htmlspecialchars_decode($row['band316'], ENT_QUOTES),htmlspecialchars_decode($row['band317'], ENT_QUOTES), htmlspecialchars_decode($row['band318'], ENT_QUOTES),htmlspecialchars_decode($row['band319'], ENT_QUOTES), htmlspecialchars_decode($row['band320'], ENT_QUOTES)];				 
}elseif ($day == "4"){
	$bands = ["filler", htmlspecialchars_decode($row['band401'], ENT_QUOTES), htmlspecialchars_decode($row['band402'], ENT_QUOTES), htmlspecialchars_decode($row['band403'], ENT_QUOTES), htmlspecialchars_decode($row['band404'], ENT_QUOTES), htmlspecialchars_decode($row['band405'], ENT_QUOTES), htmlspecialchars_decode($row['band406'], ENT_QUOTES),htmlspecialchars_decode($row['band407'], ENT_QUOTES), htmlspecialchars_decode($row['band408'], ENT_QUOTES),htmlspecialchars_decode($row['band409'], ENT_QUOTES), htmlspecialchars_decode($row['band410'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band411'], ENT_QUOTES), htmlspecialchars_decode($row['band412'], ENT_QUOTES), htmlspecialchars_decode($row['band413'], ENT_QUOTES), htmlspecialchars_decode($row['band414'], ENT_QUOTES), htmlspecialchars_decode($row['band415'], ENT_QUOTES), htmlspecialchars_decode($row['band416'], ENT_QUOTES),htmlspecialchars_decode($row['band417'], ENT_QUOTES), htmlspecialchars_decode($row['band418'], ENT_QUOTES),htmlspecialchars_decode($row['band419'], ENT_QUOTES), htmlspecialchars_decode($row['band420'], ENT_QUOTES)];
}elseif ($day == "5"){
	$bands = ["filler", htmlspecialchars_decode($row['band501'], ENT_QUOTES), htmlspecialchars_decode($row['band502'], ENT_QUOTES), htmlspecialchars_decode($row['band503'], ENT_QUOTES), htmlspecialchars_decode($row['band504'], ENT_QUOTES), htmlspecialchars_decode($row['band505'], ENT_QUOTES), htmlspecialchars_decode($row['band506'], ENT_QUOTES),htmlspecialchars_decode($row['band507'], ENT_QUOTES), htmlspecialchars_decode($row['band508'], ENT_QUOTES),htmlspecialchars_decode($row['band509'], ENT_QUOTES), htmlspecialchars_decode($row['band510'], ENT_QUOTES),
                 htmlspecialchars_decode($row['band511'], ENT_QUOTES), htmlspecialchars_decode($row['band512'], ENT_QUOTES), htmlspecialchars_decode($row['band513'], ENT_QUOTES), htmlspecialchars_decode($row['band514'], ENT_QUOTES), htmlspecialchars_decode($row['band515'], ENT_QUOTES), htmlspecialchars_decode($row['band516'], ENT_QUOTES),htmlspecialchars_decode($row['band517'], ENT_QUOTES), htmlspecialchars_decode($row['band518'], ENT_QUOTES),htmlspecialchars_decode($row['band519'], ENT_QUOTES), htmlspecialchars_decode($row['band520'], ENT_QUOTES)];				 
}
$dbconnect->close();	

function MakeDrop($things){	
global $shortcut;
$shortcut="<option value='null'>not used</option>";
foreach ($things as &$value){$shortcut.="<option value='$value'>$value</option>";
}
 $shortcut.="</select>";
return $shortcut;}

function MakeNiceDrop($things){	
global $shortcut;
$shortcut="<option value='null'>not used</option>";
foreach ($things as &$value){$shortcut.="<option style='background-color:$value;' value='$value'>$value</option>";
}
 $shortcut.="</select>";
return $shortcut;}

MakeDrop($mic_list);
$micDrop=$shortcut;
MakeDrop($standlist);
$standDrop=$shortcut;
MakeNiceDrop($boxlist);
$boxDrop=$shortcut;

echo "<div id='editsat'></div><div id='patchupdate' style='clear:both;'> </div>";
$dbname= "stagepatch";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, "SELECT * FROM `$show`");

/*generic patch page */
if ($day==69){ 
echo "<label for='48v'>Choose +48v master: </label><select id='phantom' name='phantom' onchange='boxsize(this.value,`phantom`,`ch`)'> <option value='null'>select </option>
      <option style='background-color:{$row['fohcol']};' value='foh'> Front of House</option><option style='background-color:{$row['moncol']};' value='mon'>Monitors</option></select><script async>document.getElementById('phantom').value = {$row['48v']}</script>";
if ($defaultshow != 1){echo "<div id='defaultbutton'> Default show: <button onClick='defaults(`show`, `$show`, `1`);'>make default show</button></div>";}
echo"<br>Edit satalite box Configuration (Channel count, number of duplicate boxes) :<div class='flex-container' width=100%>";
function satBox($col,$colsize){
echo "<div style='flex-basis: 200px; text-align: right; white-space: nowrap;'><label for='$col'>$col:</label><select id='$col' name='$col' onchange='boxsize(this.value,`$col`,`ch`)'";
 if (($colsize != '0')and($colsize!='null')){
 echo "style=background-color:$col;";
	 if ($col==='black'){echo "color:white;";}}
 echo "> <option value='null'>select size</option><option value='0'> Not used </option><option value='4'>4 ch (Cat snake)</option>
  <option value='8'>8 ch</option><option value='12' >12 ch</option><option value='16'>16 ch</option><option value='32'>32 ch</option>
</select><script async> document.getElementsByName('$col')[0].value = '$colsize' </script><select onchange='boxsize(this.value,`$col`,`riser`)'><option value=null></option><option value='1'>1</option><option value='2'>2</option><option value='3'>3</option></select></div>";
}

satBox('red',$row['redsize']);
satBox('blue',$row['bluesize']);
satBox('green',$row['greensize']);
satBox('yellow',$row['yellowsize']);
satBox('white',$row['whitesize']);
echo "</div><div class='flex-container'>";
satBox('brown',$row['brownsize']);
satBox('purple',$row['purplesize']);
satBox('grey',$row['greysize']);
satBox('orange',$row['orangesize']);
satBox('black',$row['blacksize']); 
echo "</div><button onClick='window.location.reload();'>Autofill</button>
<div style='clear:both; text-align:center;'>
<div id='test'></div>
<table border='1'>
<tr><th colspan='16'>Festival Patch - $show</th></tr><tr >
  <th>ID</th>
  <th>Split</th>
  <th> FOH io</th>
  <th>Mon io </th>
  <th>FOH ch</th>
  <th>Mon ch</th>
  <th>Name</th>
  <th>48v</th>
  <th>Mic </th>
  <th>Hardware</th>
  <th>cable </th>
  <th>riser count</th>
  <th>satcol</th>
  <th>satch </th>
  <th>ysatcol</th>
  <th>ysatch</th></tr>"; 

$i=1;
$split=[''];
$fohio=[''];
$monio=[''];
$fohch=[''];
$monch=[''];
$names=[''];
$mics=[''];
$hw=[''];
$cables=[''];
$risers=[''];
$satcol=[''];
$satch=[''];
$ysatcol=[''];
$ysatch=[''];
while ($row = mysqli_fetch_array($query)) {	
$split[]=$row['splitter'];
$fohio[]=$row['fohio'];
$monio[]=$row['monio'];
$fohch[]=$row['fohch'];
$monch[]=$row['monch'];
$names[]=htmlspecialchars_decode($row['name'], ENT_NOQUOTES);
$mics[]=$row['defaultmic'];
$hw[]=$row['defaulthardware'];
$cables[]=$row['cable'];
$risers[]=$row['risercount'];
$satcol[]=$row['satcol'];
$satch[]=$row['satch'];
$ysatcol[]=$row['ysatcol'];
$ysatch[]=$row['ysatch'];
  echo
   "<tr><td>{$row['id']}</td><td><input type='text' id=splitter$i name=genfill onchange='editpatch(this.value, `splitter`, `$i`, `$day`)' size='2' > </td>
		 <td><input type='text' id=fohio$i name=genfill onchange='editpatch(this.value, `fohio`, `$i`, `$day`)' size='4'></td>
	 <td><input type='text' id=monio$i name=genfill onchange='editpatch(this.value, `monio`, `$i`, `$day`)' size='4'></td>
	 <td><input type='text' id=fohch$i name=genfill onchange='editpatch(this.value, `fohch`, `$i`, `$day`)' size='3'></td>
	 <td><input type='text' id=monch$i name=genfill onchange='editpatch(this.value, `monch`, `$i`, `$day`)' size='3'></td>
     <td><input type='text' id=name$i name=genfill onchange='editpatch(this.value, `name`, `$i`, `$day`)' size='20'></td>
	 <td><input type='checkbox' id=48v$i name=48v$i  onchange='editpatch(this.checked, `48v`, `$i`, `$day`)' ";
	 if ($row['48v']==1) {echo "checked";}
	 echo "></td><td><select id=defaultmic$i name=genfill onchange='editpatch(this.value, `defaultmic`, `$i`, `$day`)'>{$micDrop}";
    echo "</td><td>
	<select id=defaulthardware$i name=genfill onchange='editpatch(this.value, `defaulthardware`, `$i`, `$day`)'>{$standDrop}</td>
	<td><select id=cable$i name=genfill onchange='editpatch(this.value, `cable`, `$i`, `$day`)'><option value='0'></option>";
	$c=0;
	foreach ($cable_lengths as &$value){
		if ($value !=0){
		echo "<option style='background-color:{$cable_cols[$c]};' value='$value'>$value</option>";
	}$c++;}
	echo "</select></td>	 <td><input type='text' id=risercount$i name=genfill onchange='editpatch(this.value, `risercount`, `$i`, `$day`)' size='2' ></td>
	 <td style='background-color:{$row["satcol"]}'><select id=satcol$i name=genfill onchange='editpatch(this.value, `satcol`, `$i`, `$day`)'>{$boxDrop}</td>
	 <td style='background-color:{$row["satcol"]}'><input type='text' id=satch$i name=genfill onchange='editpatch(this.value, `satch`, `$i`, `$day`)' size='2'></td>
	<td style='background-color:{$row["ysatcol"]}'><select id=ysatcol$i name=genfill onchange='editpatch(this.value, `ysatcol`, `$i`, `$day`)' >{$boxDrop}</td>
	 <td style='background-color:{$row["ysatcol"]}'><input type='text' id=ysatch$i name=genfill onchange='editpatch(this.value, `ysatch`, `$i`, `$day`)' size='2' ></td></tr>";
$i++;}
echo "</table></div>";

function genfill($split, $fohio, $monio,$fohch,$monch,$names,$mics, $hw, $cables, $risers, $satcol, $satch, $ysatcol, $ysatch){

echo"<script>var genvalues=[];";
for ($x=1;$x < count($names); $x++) {
  echo"genvalues.push('{$split[$x]}', '{$fohio[$x]}','{$monio[$x]}','{$fohch[$x]}','{$monch[$x]}','{$names[$x]}', '{$mics[$x]}', '{$hw[$x]}', '{$cables[$x]}', '{$risers[$x]}', '{$satcol[$x]}', '{$satch[$x]}', '{$ysatcol[$x]}', '{$ysatch[$x]}');";
	}
echo "genboxes= document.getElementsByName('genfill'); for(var x=0; x < genboxes.length; x++) {genboxes[x].value = genvalues[x];}
</script>";
}

genfill($split, $fohio, $monio,$fohch,$monch,$names,$mics, $hw, $cables, $risers, $satcol, $satch, $ysatcol, $ysatch);

} 
/* days pages*/
else {
echo "<div class='flex-container'; id = 'all'; width=100%; style='flex-basis: auto; overflow-x:auto;'> <div id='defaultbutton'>";
if ($defaultday!=$day){echo "<button onClick='defaults(`day`, `$show`, `$day`);'>make default day</button>";}
echo "</div>Names of acts:<div id= 'band names' class='flex-container'>";
for($x=1;$x<=$lineup;$x++){
echo "<div style='flex-basis: auto; text-align: right; white-space: nowrap; padding:2px;'><label for='band$x' >Band $x:</label><input type='text' id=band$x name=band$x onchange='bandname(this.value, `$day`, `$x`)'>";
if ($bands[$x]!=null){
$output= htmlspecialchars($bands[$x]);
echo  "<script async>document.getElementsByName('band$x')[0].value = `$output`</script>";}
echo "</div>";}
$yshow="no";
$width=3;
$yquery = mysqli_query($dbconnect, "SELECT * FROM `$show`")
   or die (mysqli_error($dbconnect));
   while ($row = mysqli_fetch_array($yquery)) {
   if (!empty($row['ysatch'])){$yshow='yes';
   $width=4;
   }}

echo " <button onClick='window.location.reload();'>Autofill</button> </div><div class='flex-container' style='flex-basis:auto; flex-shink:0; overflow-x:auto;  text-align:center; '><table border='black 1px' >
<tr><th colspan=$width>$show</th></tr><tr><th colspan=$width style=' padding:2px;' >Generic</th></tr>
<tr  style='height:70px;' ><th>Split </th><th>Channel <br> Name</th><th>Sat</th>";
if ($yshow=='yes'){echo "<th>Y-Sat</th>";}

echo "</tr> ";
  
while ($row = mysqli_fetch_array($query)) {
echo "<tr><td><input type=radio name=rowfill{$row['id']}  onClick = 'bigfill(this.checked, {$row['id']}, {$day}, 0);'>{$row['splitter']}</td><td >{$row['name']} <td style='background-color:{$row['satcol']};'>{$row['satch']}</td>";
if ($yshow=='yes'){echo "<td style='background-color:{$row['ysatcol']};'>{$row['ysatch']}</td>";}
echo"</tr>";}
echo " <tr></tr></table></div><div id='bandedit' style='flex-basis:70%; flex-grow:1; flex-shrink:1; overflow-x:auto; overflow-y:auto;  white-space: nowrap; float:left; ding:0px;'><table border=1><tr ><th colspan =$bigwidth>Bands</th></tr>";
for ($x=1;$x<=$lineup;$x++){
echo "<th colspan='7'> Band$x - {$bands[$x]}  <select onChange='bigfill(this.value, `$x` ,`$day`, `both`);'><option value='null'>patch</option><option value='house'>house</option><option value='soft'>soft</option><option value='clear'>clear</option></select></th>";
}
echo "</th></tr> <tr  style='height:70px;'>";
for ($x=1;$x<=$lineup;$x++){
echo "<th>Used</th><th>Name</th><th>mic</th><th>48v</th><th>Foh<br><select onChange='bigfill(this.value, `$x` ,`$day`, `foh`);'><option value='null'>patch</option><option value='house'>house</option><option value='soft'>soft</option><option value='clear'>clear</option></select></th><th>mon<br><select onChange='bigfill(this.value, `$x` ,`$day`, `mon`);'><option value='null'>patch</option><option value='house'>house</option><option value='soft'>soft</option><option value='clear'>clear</option></select></th><th>notes</th>";
}
echo "<th>split</th></tr>";
$week =["filler", "{$show}- day 1", "{$show}- day 2", "{$show}- day 3", "{$show}- day 4", "{$show}- day 5"];
$showday= $week[$day];
$query = mysqli_query($dbconnect, "SELECT * FROM `$showday`");
$i=1;
$names=[''];
$mics=[''];
$fohch=[''];
$monch=[''];
$notes=[''];
while ($row = mysqli_fetch_array($query)) {
	echo "<tr>";
	for ($x=1;$x<=$lineup;$x++){
	  $names[]=htmlspecialchars_decode($row["bandname".$x], ENT_NOQUOTES);
	  $notes[]=htmlspecialchars_decode($row["bandnotes".$x], ENT_NOQUOTES);
	  $mics[]=$row["bandmic".$x];
	  $fohch[]= $row["bandfoh".$x];
	  $monch[]=$row["bandmon".$x];
	  if ($row["bandused".$x]== 1){$used="checked";}else{$used="";}
	  echo "<td><input type='checkbox' id=bandused$x$i name=bandused$x$i  onchange='copyname(this.checked,$x,$i,$day);'{$used}></td><td><input type='text' id=bandname$x$i name=bandfill onchange='editpatch(this.value, `bandname$x`, `$i`, `$day`)' size='10'></td>
       <td><select id=bandmic$x$i name=bandfill onchange='editpatch(this.value, `bandmic$x`, `$i`, `$day`)'>{$micDrop}</td>
	<td><input type='checkbox' id=bandphantom$x$i name=bandphantom$x$i  onchange='editpatch(this.checked, `bandphantom$x`, `$i`, `$day`)'";
	if ($row["bandphantom".$x]== 1){echo"checked";}
	echo "> </td><td><input type='text' id=bandfoh$x$i name=bandfill onchange='editpatch(this.value, `bandfoh$x`, `$i`, `$day`)' size='2'></td>
    <td><input type='text' id=bandmon$x$i name=bandfill onchange='editpatch(this.value, `bandmon$x`, `$i`, `$day`)' size='2'></td>
	 <td><input type='text' id=bandnotes$x$i name=bandfill onchange='editpatch(this.value, `bandnotes$x`, `$i`, `$day`)'size='6'> 
	</td>";}
	echo "<td>{$row['splitter']}</td></tr>";
	$i++;}
echo "</table>line</div></div></div></div>"; 

function autofill($names,$mics,$fohch,$monch,$notes){
echo"<script async>var values=[];";
for($x=1; $x< count($names); $x++) {
    echo"values.push('{$names[$x]}', '{$mics[$x]}','{$fohch[$x]}','{$monch[$x]}', '{$notes[$x]}');";}
echo "boxes= document.getElementsByName('bandfill'); for(var x=0; x < boxes.length; x++) {boxes[x].value = values[x];}</script>";
}

autofill($names,$mics,$fohch,$monch,$notes);}
?>
<script async>
function boxsize(e,t,m){if(""!=e){var n=new XMLHttpRequest;n.onreadystatechange=function(){4==this.readyState&&200==this.status&&(document.getElementById("editsat").innerHTML=this.responseText)},n.open("GET","../resources/update.php?showname=<?php echo $show;?>&size="+e+"&col="+t+"&mode="+m,!0),n.send(),document.getElementById("page").value="69",document.getElementById("pageform").submit()}else document.getElementById("editsat").innerHTML=""}
function editpatch(e,t,a,n){var s=new XMLHttpRequest;s.onreadystatechange=function(){4==this.readyState&&200==this.status&&(document.getElementById("patchupdate").innerHTML=this.responseText)},s.open("GET","../resources/update.php?showname=<?php echo $show;?>&id="+a+"&value="+e+"&cat="+t+"&day="+n,!0),s.send()}
function copyname(e,t,a,n){var s=new XMLHttpRequest;s.onreadystatechange=function(){4==this.readyState&&200==this.status&&(document.getElementById("patchupdate").innerHTML=this.responseText)},s.open("GET","../resources/autofill.php?showname=<?php echo $show;?>&id="+a+"&value="+e+"&place="+t+"&day="+n,!0),s.send(),updateDiv()}
function bandname(e,t,n){var a=new XMLHttpRequest;a.onreadystatechange=function(){4==this.readyState&&200==this.status&&(document.getElementById("patchupdate").innerHTML=this.responseText)},a.open("GET","../resources/autofill.php?showname=<?php echo $show;?>&id="+n+"&value="+e+"&day="+t,!0),a.send(),updateDiv()}
function bigfill(e,t,s,n){var h=new XMLHttpRequest;h.onreadystatechange=function(){4==this.readyState&&200==this.status&&(document.getElementById("patchupdate").innerHTML=this.responseText)},h.open("GET","../resources/bigfill.php?showname=<?php echo $show;?>&lineup=<?php echo $lineup;?>&showsize=<?php echo $showsize;?>&id="+t+"&value="+e+"&day="+s+"&type="+n,!0),h.send()}
function defaults (mode, show, value){var h=new XMLHttpRequest;h.onreadystatechange=function(){4==this.readyState&&200==this.status&&(document.getElementById("defaultbutton").innerHTML=this.responseText)},h.open("GET","../resources/defaults.php?showname="+show+"&value="+value+"&mode="+mode,!0),h.send()}
</script></body></html>