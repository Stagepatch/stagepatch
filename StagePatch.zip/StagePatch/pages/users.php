<!DOCTYPE html>
<html>
<!--user preferences page-->
<head></head><body>
<table><form id="userform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
<tr><td><label for="user">select user profile</label>
<select id="user" name="user" onchange="this.form.submit()">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "stagepatchpreferences";
function fill_colours(){
	echo "<option value='null'>select colour</option>
	<option style='background-color:brown;' value='brown'> Brown</option><option style='background-color:red;' value='red'> Red</option>
  <option style='background-color:orange;' value='orange' >Orange</option> <option style='background-color:yellow;' value='yellow'>Yellow</option>
  <option style='background-color:green;' value='green'>Green</option><option style='background-color:blue;' value='blue'>Blue</option>
  <option style='background-color:purple;' value='purple'>Purple</option><option style='background-color:pink;' value='pink'>Pink</option>
  <option style='background-color:grey;' value='grey' >Grey</option><option style='background-color:white;' value='white'>White</option>
  <option style='background-color:black; color: white;' value='black'>Black</option></select>";}

// Create connection
$dbconnect = mysqli_connect($servername, $username, $password, $dbname);
if ($dbconnect->connect_error) {
  die("Connection failed: " . $dbconnect->connect_error);
}
$showusers = $dbconnect->query("SELECT name FROM users");
echo"<option value='null'>select user profile</option>
<option value='newuser'>create new user</option>";
while($user = mysqli_fetch_array($showusers)) { 
  echo("<option value='$user[0]'>$user[0]</option>");  
 }
 echo "</select></td></tr></table></form><br>";
 echo "<div id='update'></div>";  
if (isset($_POST['user'])) {
	$loggedin=filter_var(trim($_POST["user"]), FILTER_SANITIZE_SPECIAL_CHARS);
	
	  

 if ($loggedin == "newuser") {
	  echo "<h3>Create a new user</h3>
	 <form id='newuser' method='post'><label for='user' >User Name:</label>
  <input type='text' id='user' name='user' >
  <input type='hidden' name='newuser' value='new'><input type='submit' value='Create'></form>";
	 
  }
  
  else{
  if (isset($_POST['newuser'])){
  if ($_POST['newuser']==='new'){
	  $query=$dbconnect->query("SELECT * FROM `users`");
	  $userlist=[];
	  $error="";
	  while ($row=mysqli_fetch_array($query)){$userlist[]=$row['name'];}
	  if ($loggedin===""){$error="blank user name submited, please try again";}
      elseif (strlen($loggedin)>20){$error="username too long, maximum length is 20 characters";}
       elseif (in_array($loggedin, $userlist)){$error="user name already exists";}
      if ($error ===''){
      $stmt = "INSERT INTO `users`(`name`) VALUES ('$loggedin')";
      $query = mysqli_query($dbconnect, $stmt);
      echo "new user- {$loggedin} - created.<form method='post' > <input type='hidden' name='newuser' value='done'><input type='hiden' name='users' value='". $loggedin."'><input type='submit' value='Continue'></form>";
	  }else{echo $error."<h3>Create a new user</h3>
	 <form id='newuser' method='post'><label for='user' >User Name:</label>
  <input type='text' id='user' name='user' >
  <input type='hidden' name='newuser' value='new'><input type='submit' value='Create'></form>";}
  }}
	  else{ 
 echo "<h3> $loggedin </h3>";
echo "<div id='userpref'>";
 
 
$stmt="SELECT * FROM `users` WHERE `name` = '$loggedin'";
$dbconnect=mysqli_connect($servername,$username,$password,$dbname);
$query = mysqli_query($dbconnect, $stmt);
$row = mysqli_fetch_array($query);
echo "set default sat box configuration:
<form action=";
echo htmlspecialchars($_SERVER['PHP_SELF']);
echo " method='post'>
<table STYLE='text-align:right; border: 1px solid black; clear:both;'><tr>";

 
function satBox($col,$colsize){
	echo "<td><label for='$col'>$col:</label>
<select id='$col' name='$col' onchange='boxsize(this.value,`$col`)'";
 if (($colsize != '0')and($colsize!='null')){
 echo "style=background-color:$col;";
	 if ($col=='black'){echo "color:white;";}}
 echo "> <option value='null'>select size</option>
  <option value='0'> Not used </option>
  <option value='4'>4 ch (Cat snake)</option>
  <option value='8'>8 ch</option>
  <option value='12' >12 ch</option>
  <option value='16'>16 ch</option>
  <option value='32'>32 ch</option>
</select><script> document.getElementsByName('$col')[0].value = '$colsize' </script></td>";
}
satBox('red',$row['redsize']);
satBox('blue',$row['bluesize']);
satBox('green',$row['greensize']);
satBox('yellow',$row['yellowsize']);
satBox('orange',$row['orangesize']);
echo "<br></tr><tr>";
satBox('brown',$row['brownsize']);
satBox('purple',$row['purplesize']);
satBox('grey',$row['greysize']);
satBox('white',$row['whitesize']);
satBox('black',$row['blacksize']);

echo "</tr></table><br><br> Set cable lengths and colours:
<table STYLE='text-align:right; border: 1px solid black; clear:both;'><tr>";

function cables($x, $length, $colour){
  echo "<td><input type='text' id='len$x' name='len$x' onchange='editcable(this.value, `$x`, `length`)' style=background-color:$colour; size=3>
       <script> document.getElementsByName('len$x')[0].value = [0].value = '$length'</script>
        <select id='col$x' name='col$x'onchange='editcable(this.value,`$x`, `col`)' style=background-color:$colour;>";
  fill_colours();
  echo "<script> document.getElementsByName('col$x')[0].value = [0].value = '$colour'</script></td>";
}
cables(1, $row['len1'], $row['col1']);
cables(2, $row['len2'], $row['col2']);
cables(3, $row['len3'], $row['col3']);
cables(4, $row['len4'], $row['col4']);
cables(5, $row['len5'], $row['col5']);
echo "</tr>";
cables(6, $row['len6'], $row['col6']);
cables(7, $row['len7'], $row['col7']);
cables(8, $row['len8'], $row['col8']);
cables(9, $row['len9'], $row['col9']);
cables(10, $row['len10'], $row['col10']);
echo "</table><br><br>
Select preffered accent colours:
<table STYLE='text-align:right; border: 1px solid black; clear:both;'><tr>
<td><label for='fohcol'>Front of House:</label>
<select id='fohcol' name='fohcol' onchange='boxsize(this.value,`foh`)'
 style=background-color:{$row['fohcol']}; >";
fill_colours();
echo "<script>document.getElementsByName('fohcol')[0].value = '{$row['fohcol']}'
</script></td>
<td><label for='moncol'>Monitors:</label>
<select id='moncol' name='moncol' onchange='boxsize(this.value,`mon`);'
 style=background-color:{$row['moncol']}; >";
 fill_colours();
echo "<script> document.getElementsByName('moncol')[0].value = '{$row['moncol']}'
</script></td></tr>
</table>

</form></div>";
}}}
?>


<script>
function boxsize(size, col) {
  if (size == "") {
    document.getElementById("update").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("update").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","../resources/update.php?loggedin=<?php echo $loggedin;?>&size="+size+"&col="+col,true);
    xmlhttp.send();
  }
  document.getElementById('user').value = "<?PHP echo $loggedin; ?>";
  document.getElementById('userform').submit();
 
}

function newuser(name) {
  if (name == "") {
    document.getElementById("update").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("update").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","../resources/update.php?new=new&loggedin="+name,true);
    xmlhttp.send();
  }
  }


function editcable(value, number, type) {
  if (value == "") {
    document.getElementById("update").innerHTML = "";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("update").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET","../resources/update.php?loggedin=<?php echo $loggedin;?>&size="+value+"&col="+type+"&no="+number,true);
    xmlhttp.send();
  }
  document.getElementById('user').value = "<?PHP echo $loggedin; ?>";
  document.getElementById('userform').submit();
 
}




</script>
</body></html>